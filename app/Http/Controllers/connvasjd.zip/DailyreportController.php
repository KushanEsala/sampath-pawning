<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\TPawnSum;
use App\Models\TRedeemSum;
use App\Models\TOpeningPawnDetails;
use App\Models\TOpeningPawnSum;
use App\Models\TPawnDetails;
use App\Models\TPaymentVoucher;
use App\Models\TGentralReceipt;
use App\Models\DailyReport;
use Carbon\Carbon;

use App\Models\Datatables;

class dailyreportController extends Controller
{
    public function getYesterdayCashBalance()
    {
        $yesterdayDate = Carbon::yesterday();
        $branchCode = auth()->user()->BC;

        $yesterdayReport = DailyReport::where('to_date', $yesterdayDate)
            ->where('BC', $branchCode)
            ->first();

        if ($yesterdayReport) {
            return $yesterdayReport->net_balance;
        }

        // If there is no report for yesterday, you might want to handle it accordingly
        return 0;
    }

    public function index(Request $request)

    {
        $branch_code = auth()->user()->BC;


         $fromDate  = $request->input('from_date');
         $toDate = $request->input('to_date');

    $quer = TPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $query = TRedeemSum::whereBetween('Redeem_Date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $Open = TOpeningPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $Receip = TGentralReceipt::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $phone = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',003)
    ->get();

    $Elecricity = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',001)
    ->get();

    $water = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',007)
    ->get();

    $Other = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',103)
    ->get();

    $Sundary = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',101)
    ->get();

    $StaffSalary= TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',002)
    ->get();

    $Travelling = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',004)
    ->get();

    $Advance = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',006)
    ->get();

    $headOfficeReturn = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',105)
    ->get();

   $WesternUnionPaid = TPaymentVoucher::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->where('drcode',102)
    ->get();



                $fromDate  = $request->input('from_date');
                $toDate = $request->input('to_date');

// Construct a query to filter records based on search criteria
$quer = TPawnSum::query();
$query = TRedeemSum::query();
$que = TPaymentVoucher::query();
$Receip = TGentralReceipt::query();


if ($fromDate && $toDate) {

    $quer = TPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $query = TRedeemSum::whereBetween('Redeem_Date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();

    $Receip = TGentralReceipt::whereBetween('date', [$fromDate, $toDate])
    ->where('BC',$branch_code)
    ->get();




}

        $Pawning = $quer->sum('Amount');
        $Pawningpayemt = number_format($Pawning, 2);

        $int = $query->sum('Payable_Total');
        $Redeempayment = number_format($int , 2);

        // $Amount = $Open->sum('Total_Amount');
        // $OpeningBalance = number_format($Amount, 2);

        $ElecricityBill = $Elecricity->sum('amount');
        $Elecricitytotal = number_format($ElecricityBill, 2);

        $OtherBill = $Other->sum('amount');
        $Othertotal = number_format($OtherBill, 2);

        $SundryBill = $Sundary->sum('amount');
        $Sundrytotal = number_format($SundryBill, 2);

        $StaffSalaryBill = $StaffSalary->sum('amount');
        $StaffSalarytotal = number_format($StaffSalaryBill, 2);

        $TravellingBill = $Travelling->sum('amount');
        $Travellingtotal = number_format($TravellingBill, 2);

        $AdvanceBill = $Advance->sum('amount');
        $Advancetotal = number_format($AdvanceBill, 2);

        $WesternUnionPaidBill = $WesternUnionPaid->sum('amount');
        $WesternUnionPaidtotal = number_format($WesternUnionPaidBill, 2);

        $WaterBill = $water->sum('amount');
        $WaterTotal = number_format($WaterBill, 2);

        $PhoneBill = $phone->sum('amount');
        $PhoneTotal = number_format($PhoneBill, 2);

        $Pawn = $quer->sum('Interest');
        $payemt = number_format($Pawn, 2);

        $Stamp = $query->sum('Stamp_Fee');
        $Stamppayemt = number_format($Stamp, 2);

        $Document = $query->sum('Document_Charges');
        $Documen = number_format($Document, 2);

        $headoffice = $Receip->sum('amount');
        $headoffic = number_format($headoffice, 2);

        $headofficereturnBill = $headOfficeReturn->sum('amount');
        $headofficereturntotal = number_format($headofficereturnBill, 2);

        $pawbalance = $Pawning;
        $pawnbalance = number_format($pawbalance , 2);

        $yesterdayCashBalance = $this->getYesterdayCashBalance();

                // calulation
                $result = $pawbalance ;
                $res = $result  + $Pawn;
        
                $Totalin =$Pawn +  $Stamp + $Document + $headoffice + $yesterdayCashBalance + $int;
                $Totalinput = number_format($Totalin , 2);
        
        
         // Get Total Value of Expense
                $totalout = $Pawning +  $WaterBill  +  $PhoneBill  + $ElecricityBill +  $OtherBill + $SundryBill +  $StaffSalaryBill  + $TravellingBill +  $AdvanceBill  +  $WesternUnionPaidBill ;
                $totaloutcome = number_format($totalout , 2);
                $netamount = $Totalin - $totalout;
                $payment = number_format($netamount , 2);


        if (auth()->check()) {
            $todayReport = DailyReport::updateOrCreate(
                [
                    'to_date' => $toDate = $request->input('to_date'),
                    'BC' => auth()->user()->BC,
                ],
                [
                    'net_balance' => $netamount,
                    // ...
                ]
            );
        } else {
            // Handle the case when the user is not authenticated
        }
        

        return view('daily_report')

        -> with("summary", $query)
        -> with("quer", $quer)
        -> with("query ",$query )
        -> with("que", $que)
        -> with("phone",  $phone)
        -> with("Open", $Open)
        -> with("Receip", $Receip)
        ->with('Payable_Total',$Redeempayment)
        ->with('Total_Amount',$Pawningpayemt )
        // ->with('Amount',$OpeningBalance )
        ->with('Interest',$payemt)
        ->with('Stamp_Fee',$Stamppayemt)
        ->with('result',$result)
        ->with('balance',$pawnbalance)
        ->with('res',$res)
        ->with('tolin',$Totalinput)
        ->with('WaterAmount',$WaterTotal)
        ->with('Document_Charges',$Documen)
        ->with('PhoneAmount',$PhoneTotal)
        ->with('amountt',$headoffic)
        ->with('totalout',$totaloutcome)
        ->with('Elecricity',$Elecricitytotal )
        ->with('Others',$Othertotal)
        ->with('sundry',$Sundrytotal)
        ->with('staffsalary',$StaffSalarytotal)
        ->with('Travelling',$Travellingtotal)
        ->with('advance',$Advancetotal)
        ->with('WesternUnionPaid',$WesternUnionPaidtotal)
        ->with('HeadOfficeReturn',$headofficereturntotal)
        ->with('BC',$branch_code)
        ->with('Travelling',$Travellingtotal)
        ->with('yesterdayCashBalance',$yesterdayCashBalance)
        ->with('net',$payment);

    }
    
}