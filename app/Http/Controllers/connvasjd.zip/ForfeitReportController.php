<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TPawnSum;
use App\Models\TOpeningPawnSum;

class ForfeitReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    // Get search criteria from the form input
    $fromDate  = $request->input('from_date');
    $toDate = $request->input('to_date');

    $query = TPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
            ->where('IsRedeemed', 0)
            ->where('isForfeit', 1)
            ->get();

    if ($fromDate && $toDate) {
        $dataTPawnSum = TPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
                        ->where('IsRedeemed', 0)
                        ->where('isForfeit', 1)
                        ->get();

        $dataTOpeningPawnSum = TOpeningPawnSum::whereBetween('Receipt_Date', [$fromDate, $toDate])
                                ->where('IsRedeemed', 0)
                                ->where('isForfeit', 1)
                                ->get();

        $data = $dataTPawnSum->concat($dataTOpeningPawnSum);

        $total = $data->sum('Amount');
        $totalAmount = number_format($total, 2);
        $int =  $data->sum('Interest');
        $interest = number_format($int, 2);

        return view('forfeitReport')
         ->with("recipts", $data)
        -> with("recipts", $data)
        -> with("amount", $totalAmount)
        -> with("Interest", $interest);
    }

    // Construct a query to filter records based on search criteria
    $query = TPawnSum::query();

    $total = $query->sum('Amount');
    $totalAmount = number_format($total, 2);
    $int =  $query->sum('Interest');
    $interest = number_format($int, 2);
    $TotalPawn = TPawnSum::count();

    return view('forfeitReport')
    -> with("recipts", $query)
    -> with("recipts", $query)
    -> with("amount", $totalAmount)
    -> with("Interest", $interest);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
