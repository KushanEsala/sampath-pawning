<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Recei_Add;
class ReceiptController extends Controller
{
    public function index(){
        $receipt = Recei_Add::latest()->paginate(7);
        return view('receipt')->with("Recei_Add" , $receipt);
    }

    public function index_forfeit_receipt(){
        return view('ForfeitReceipt');
    }


    // ------------- Create receipt using Ajex-------------
    public function create(Request $request){
        $request->validate([
            'receiptname'=>'required | max:80 |unique:recei__adds,receiptname,'.$request->id,
            'rate1'=>'required | numeric  ',
            'rate2'=>'required | numeric  ',
            'rate3'=>'required | numeric  ',
            'period1'=>'required | numeric ',
            'period2'=>'required | numeric ',
            'period3'=>'required | numeric ',
            'valid'=>'required | numeric ',
            's_char_less'=>'required | numeric ',
            's_char_grea'=>'required | numeric ',
        ]);

        $receipt = new Recei_Add;
        $receipt->receiptname = $request->receiptname;
        $receipt->rate1 = $request->rate1;
        $receipt->period1 = $request->period1;
        $receipt->rate2 = $request->rate2;
        $receipt->period2 = $request->period2;
        $receipt->rate3 = $request->rate3;
        $receipt->period3 = $request->period3;
        $receipt->validPeriod = $request->valid;
        $receipt->s_charge_less = $request->s_char_less;
        $receipt->s_charge_greater = $request->s_char_grea;
        $receipt->save();
        return response()->json([
            'status'=>'success',
        ]);
    }

    // ------------- delete receipt using Ajex-------------
    public function delete(Request $request)
    {
        Recei_Add::find($request->receipt_id)->delete();
        return response()->json([
            'status'=>'success',
        ]);
    }



    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request)
    {
        $request->validate([
            'up_receiptname'=>'required | max:80 '.$request->id,
            'up_rate1'=>'required | numeric  ',
            'up_rate2'=>'required | numeric  ',
            // 'up_rate3'=>'required | numeric  ',
            'up_period1'=>'required | numeric ',
            'up_period2'=>'required | numeric ',
            // 'up_period3'=>'required | numeric ',
            'up_valid'=>'required | numeric ',
            'up_s_char_less'=>'required | numeric ',
            'up_s_char_grea'=>'required | numeric ',
        ]);


        Recei_Add::where('id',$request->up_id)->update([
            'receiptname'=>$request->up_receiptname,
            'rate1'=>$request->up_rate1,
            'rate2'=>$request->up_rate2,
            'rate3'=>$request->up_rate3,
            'period1'=>$request->up_period1,
            'period2'=>$request->up_period2,
            'period3'=>$request->up_period3,
            'validPeriod' => $request->up_valid,
            's_charge_less' => $request->up_s_char_less,
            's_charge_greater' => $request->up_s_char_grea,

        ]);

        return response()->json([
            'status'=>'success',
        ]);
    }

    public function destroy($id)
    {
        $data = Recei_Add::find($id);
        $data->delete();
        return redirect()->back()->with("delete", "Receipt deleted");
    }
}
