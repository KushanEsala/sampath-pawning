<?php
 
namespace App\Http\Controllers; 
use Illuminate\Http\Request;
use App\Models\TGentralReceipt;
use App\Models\MChartofAccount;
use Datatables;
 
// Amount

class GentralReceiptController extends Controller
{
    // public function index()
    // {
    //     if(request()->ajax()) {
    //         return datatables()->of(TGentralReceipt::select('*'))
    //         ->addColumn('action', 'Action_button')
    //         ->rawColumns(['action'])
    //         ->addIndexColumn()
    //         ->make(true);
    //     }
    //     $ChartAccount = MChartofAccount::all();
    //     return view('gentralreceipt')
    //     -> with("Amount", $ChartAccount);
    // }
    
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(TGentralReceipt::where('BC', auth()->user()->BC)->select('*'))
            ->addColumn('action', 'Action_button')
            ->rawColumns(['action'])
            ->addIndexColumn()
            ->make(true);
        }



        $ChartAccount = MChartofAccount::all();
        return view('gentralreceipt')
        -> with("Amount", $ChartAccount);
    }
 
    public function addGentralReceipt(Request $request)
    {  
  
        $DepartmentId = $request->id;
  
        $Department   =   TGentralReceipt::updateOrCreate(
                    [
                     'id' => $DepartmentId
                    ],
                    [
                    'date' => $request->date,    
                    'cramount' => $request->cramount, 
                    'crcode' => $request->crcode, 
                    'dramount' => $request->dramount,
                    'drcode' => $request->drcode,
                    'description' => $request->description, 
                    'amount' => $request->amount,
                    'OC' => $request->OC, 
                    'BC' => $request->BC,
                    ]);    
                          

                    	// [ 'cramount','dramount','description','amount','OC','BC'];
        return Response()->json($Department);
    }
 
    public function UpdateGentralReceipt(Request $request)
    {   
        $where = array('id' => $request->id);
        $Department  = TGentralReceipt::where($where)->first();
       
        return Response()->json($Department);
    }
    
 
    public function DeleteGentralReceipt(Request $request)
    {
        $Department = TGentralReceipt::where('id',$request->id)->delete();
       
        return Response()->json($Department);
    }

   

}

