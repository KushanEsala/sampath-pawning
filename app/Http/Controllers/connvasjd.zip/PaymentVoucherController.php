<?php
 
namespace App\Http\Controllers; 
use Illuminate\Http\Request;
use App\Models\TPaymentVoucher;
use App\Models\MChartofAccount;
use Datatables;
 
// Amount

class PaymentVoucherController extends Controller
{
    // public function index()
    // {
    //     if(request()->ajax()) {
    //         return datatables()->of(TPaymentVoucher::select('*'))
    //         ->addColumn('action', 'Action_button')
    //         ->rawColumns(['action'])
    //         ->addIndexColumn()
    //         ->make(true);
    //     }
    //     $ChartAccount = MChartofAccount::all();
    //     return view('PaymentVoucher')
    //     -> with("Amount", $ChartAccount);
    // }
 
     public function index()
        {
            if(request()->ajax()) {
                return datatables()->of(TPaymentVoucher::where('BC', auth()->user()->BC)->select('*'))
                ->addColumn('action', 'Action_button')
                ->rawColumns(['action'])
                ->addIndexColumn()
                ->make(true);
            }
    
    
    
            $ChartAccount = MChartofAccount::all();
            return view('PaymentVoucher')
            -> with("Amount", $ChartAccount);
        }
        
    public function addPaymentVoucher(Request $request)
    {  
  
        $DepartmentId = $request->id;
  
        $Department   =   TPaymentVoucher::updateOrCreate(
                    [
                     'id' => $DepartmentId
                    ],
                    [
                    'date' => $request->date,    
                    'cramount' => $request->cramount, 
                    'crcode' => $request->crcode, 
                    'dramount' => $request->dramount,
                    'drcode' => $request->drcode,
                    'description' => $request->description, 
                    'amount' => $request->amount,
                    'OC' => $request->OC, 
                    'BC' => $request->BC,
                    ]);    
                          

                    	// [ 'cramount','dramount','description','amount','OC','BC'];
        return Response()->json($Department);
    }
 
    public function UpdatePaymentVoucher(Request $request)
    {   
        $where = array('id' => $request->id);
        $Department  = TPaymentVoucher::where($where)->first();
       
        return Response()->json($Department);
    }
    
 
    public function DeletePaymentVoucher(Request $request)
    {
        $Department = TPaymentVoucher::where('id',$request->id)->delete();
       
        return Response()->json($Department);
    }

    public function GetVoucher(Request $request){
        $Storecode = $request -> category;
        $data = MChartofAccount::where('description',$Storecode)->get();

        return response()->json([
            'status' => 'success',
            'data' => $data
        ]);

    }

    public function GetDRVoucher(Request $request){
        $DRcode = $request -> amount;
        $data = MChartofAccount::where('description',$DRcode)->get();

        return response()->json([
            'status' => 'success',
            'data' => $data
        ]);

    }

}

