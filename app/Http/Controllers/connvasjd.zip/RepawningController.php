<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use PDF;
use Illuminate\Http\Request;
use App\Models\itemCondition;
use App\Models\karatage;
use App\Models\Recei_Add;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Company;
use App\Models\TPawnDetails;
use App\Models\TPawnSum;
use App\Models\TRedeemSum;
use App\Models\TRepawningSum;
use App\Models\TOpeningPawnSum;
use App\Models\TOpeningPawnDetails;
use App\Models\branchDel;
use Carbon\Carbon;


class RepawningController extends Controller
{

    public function index()
    {
        $branch_code = auth()->user()->BC;
        $maxRedeemNo = TRedeemSum::where('BC',$branch_code)
        ->orderBy('Redeem_Number', 'desc')
        ->value('Redeem_Number');
        $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

        $branchData = branchDel::where('bccode',$branch_code)
                    ->paginate(1);

        return view('repawning')
        ->with("branchDetails", $branchData)
        ->with("maxRedeem", $maxRedeemNos);
    }

    //receipt Search function
    public function search(Request $request)
    {
        $receiptNo = $request->search_receipt_no;
        $branch_code = auth()->user()->BC;

        $dataTPawnSum = TPawnSum::where('Receipt_Number',$receiptNo)
                        ->where('IsRedeemed', 0)
                        ->where('isForfeit', 0)
                        ->where('BC',$branch_code)
                        ->get();

        $data = $dataTPawnSum;

        if($data->count()>0){
            $branch_code = auth()->user()->BC;
            $cus_nic = $data->first()->Customer_NIC;
            $cus_data = Customer::where('NIC', $cus_nic)
                        // ->where('BC',$branch_code)
                        ->get();

            $receipt_typ = $data->first()->Receipt_Type;
            $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

            $maxRedeemNo = TRedeemSum::where('BC',$branch_code)
            ->orderBy('Redeem_Number', 'desc')
            ->value('Redeem_Number');

            $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

            $pawn_type = "Pawn";


            $receiptType = Recei_Add::all();

            return view('repawningsearch')
            ->with("receiptType" , $receiptType)
            ->with("maxRedeem", $maxRedeemNos)
            ->with('customerData', $cus_data)
            ->with('receiptTypeData', $receipt_data)
            ->with('pawnType', $pawn_type)
            ->with('receiptData', $data);
        }else{
            return response()->json([
                'status'=>'not_found'
            ]);
        }
    }

    //invoice Search function
    public function searchInvoice(Request $request)
    {
        $invoiceNo = $request->search_invoice_no;
        $branch_code = auth()->user()->BC;

        $TOpeningPawnSumdata = TOpeningPawnSum::where('Invoice_Number',$invoiceNo)
                        ->where('IsRedeemed', 0)
                        ->where('isForfeit', 0)
                        ->where('BC',$branch_code)
                        ->get();

        $data = $TOpeningPawnSumdata;

        if($data->count()>0){
            $branch_code = auth()->user()->BC;

            $cus_nic = $data->first()->Customer_NIC;
            $cus_data = Customer::where('NIC', $cus_nic)
                        // ->where('BC',$branch_code)
                        ->get();

            $receipt_typ = $data->first()->Receipt_Type;
            $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

            $maxRedeemNo = TRedeemSum::where('BC',$branch_code)
                            ->orderBy('Redeem_Number', 'desc')
                            ->value('Redeem_Number');
            $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

            $pawn_type = "Opening_Pawn";

            return view('redeemSearch')
            ->with("maxRedeem", $maxRedeemNos)
            ->with('customerData', $cus_data)
            ->with('receiptTypeData', $receipt_data)
            ->with('pawnType', $pawn_type)
            ->with('receiptData', $data);

        }else{
            return response()->json([
                'status'=>'not_found'
            ]);
        }
    }

    //invoice searchTicket function
    public function searchTicket(Request $request)
    {
        $receiptNo = $request->search_receipt_no;
        $branch_code = auth()->user()->BC;

        $dataTPawnSum = TPawnSum::where('Ticket_Number',$receiptNo)
                        ->where('IsRedeemed', 0)
                        ->where('isForfeit', 0)
                        ->where('BC',$branch_code)
                        ->get();

        $data = $dataTPawnSum;

        if($data->count()>0){
            $branch_code = auth()->user()->BC;
            $cus_nic = $data->first()->Customer_NIC;
            $cus_data = Customer::where('NIC', $cus_nic)
                        // ->where('BC',$branch_code)
                        ->get();

            $receipt_typ = $data->first()->Receipt_Type;
            $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

            $maxRedeemNo = TRedeemSum::where('BC',$branch_code)
            ->orderBy('Redeem_Number', 'desc')
            ->value('Redeem_Number');

            $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

            $pawn_type = "Pawn";

            return view('redeemSearch')
            ->with("maxRedeem", $maxRedeemNos)
            ->with('customerData', $cus_data)
            ->with('receiptTypeData', $receipt_data)
            ->with('pawnType', $pawn_type)
            ->with('receiptData', $data);
        }else{
            return response()->json([
                'status'=>'not_found'
            ]);
        }
    }


     public function StoreRepawningSum(Request $request)
     {
        // Validate incoming request
        $request->validate([
            'receipt_number' => 'required|string',
            'invoice_number' => 'required|string',
            'ticket_number' => 'required|string',
            'pawn_receipt_type' => 'required|in:Pawn,SomeOtherType',
            'redeem_date' => 'required|date',
            'redeem_no' => 'required|string',
            'sum_total_weight' => 'required|numeric',
            'sum_pawn_weight' => 'required|numeric',
            'original_pawn_amount' => 'required|numeric',

        ]);
    
        try {
            // Create and save the repawning summary
            $NewRedeem = new TRepawningSum;
            $NewRedeem->Receipt_Number = $request->receipt_number;
            $NewRedeem->Invoice_Number = $request->invoice_number;
            $NewRedeem->Ticket_Number = $request->ticket_number;
            $NewRedeem->Pawn_Receipt_Type = $request->pawn_receipt_type;
            $NewRedeem->Redeem_Date = $request->redeem_date;
            $NewRedeem->Redeem_Number = $request->redeem_no;
            $NewRedeem->Total_Weight = $request->sum_total_weight;
            $NewRedeem->Pawn_Weight = $request->sum_pawn_weight;
            $NewRedeem->Original_Pawn_Amount = $request->original_pawn_amount;
            $NewRedeem->Payable_Pawn_Amount = $request->original_pawn_amount;
            $NewRedeem->Paid_Interest = $request->paid_interest;
            $NewRedeem->Payable_Interest = $request->payable_interest;
            $NewRedeem->Stamp_Fee = $request->stamp_fee;
            $NewRedeem->Document_Charges = $request->document_charges;
            $NewRedeem->Advance_Balance = $request->advance_balance ?? 0;
            $NewRedeem->Discount = $request->redeem_discount ?? 0;
            $NewRedeem->Payable_Total = $request->payable_total;
            $NewRedeem->Redeem_total = $request->redeem_total;
            $NewRedeem->validyed_type = $request->validyed_type;
            $NewRedeem->OC = auth()->user()->username;
            $NewRedeem->BC = auth()->user()->BC;
            $NewRedeem->save();
    
            $branch_code = auth()->user()->BC;
            $receiptInput_no = $request->receipt_number;
            $Pawn_Receipt_Type = $request->pawn_receipt_type;
            $Payable_Interest = $request->payable_total;
            $Interest = $request->paid_interest;
            $pawndate = $request->redeem_date;
            $Redeem_total = $request->redeem_total;
            $validyed_type = $request->validyed_type;
            $Payable_Interest_Repawn = $request->paid_interest;
    
            $companyData = Company::latest()->paginate(1);
            $branchData = branchDel::where('bccode', $branch_code)->paginate(1);

    
            $advancePayments = TPawnSum::where('Receipt_Number', $receiptInput_no)
                                     ->where('BC', $branch_code)
                                     ->get();

            $amounts = $advancePayments->pluck('Pawn_Amount'); // Extract all Amount values  
            $totalAmount = $amounts->sum(); // Sum all values in the collection

            $totalRepawnPayment = $totalAmount + $Payable_Interest + $Interest;
            
                
            $final_date_raw = $advancePayments->pluck('Receipt_Date')->first();
    
            // Convert to Carbon date
            $carbon_date = Carbon::parse($final_date_raw);
    
            // Add months
            $final_date = $carbon_date->addMonths($validyed_type);
            
             $final_date_string = $final_date->toDateString(); // format: YYYY-MM-DD


            $rate1 = Recei_Add::where('pawn_amount', '>=', 100000)->value('receiptname');
            $rate2 = Recei_Add::whereBetween('pawn_amount', [50000, 99999])->value('receiptname');
            $rate3 = Recei_Add::where('pawn_amount', '<', 50000)->value('receiptname');
        
            // Determine the interest rate based on the amount entered
            if ($totalRepawnPayment >= 100000) {
                $interestRate = $rate1;
            } elseif ($totalRepawnPayment >= 50000 && $totalRepawnPayment <= 99999) {
                $interestRate = $rate2;
            } else {
                $interestRate = $rate3;
            }


            

            $interestRate1 = Recei_Add::where('pawn_amount', '>=', 100000)->value('rate3');
            $interestRate2 = Recei_Add::whereBetween('pawn_amount', [50000, 99999])->value('rate3');
            $interestRate3 = Recei_Add::where('pawn_amount', '<', 50000)->value('rate3');

          // Determine the interest rate based on the amount entered
            if ($totalRepawnPayment >= 100000) {
                $interest = $interestRate1;
            } elseif ($totalRepawnPayment >= 50000 && $totalRepawnPayment <= 99999) {
                $interest = $interestRate2;
            } else {
                $interest = $interestRate3;
            }
    
            if ($Pawn_Receipt_Type === "Pawn") {
                // Update RePawning amount in TPawnSum
                TPawnSum::where('Receipt_Number', $receiptInput_no)
                    ->where('BC', $branch_code)
                    ->update([
                        'RePawning_amount' => $totalRepawnPayment,
                        'Pawn_Amount' => $totalRepawnPayment,
                        'RePawn_get_amount'=> $Payable_Interest,
                        'RePawning_date' => $pawndate,
                        'Pawn_Date' => $pawndate,
                        'Middle_name' => $interestRate, 
                        'Receipt_Type' => $interestRate, 
                        'Interest_Rate' => $interest, 
                        'Valid_Period'=>$validyed_type,
                        'RePawning_interest'=> $Payable_Interest_Repawn,
                        'Final_date'=> $final_date_string,

                    ]);
    
                // Fetch data for the receipt
                $T_sumdata = TPawnSum::where('Receipt_Number', $receiptInput_no)
                    ->where('BC', $branch_code)
                    ->get();
    
                $T_detailsdata = TPawnDetails::where('Receipt_Number', $receiptInput_no)
                    ->where('BC', $branch_code)
                    ->get();
    
                $T_redeemdata = TRedeemSum::where('Redeem_Number', $request->redeem_no)
                    ->where('Pawn_Receipt_Type', $Pawn_Receipt_Type)
                    ->where('BC', $branch_code)
                    ->get();
    
                // Generate the PDF content using a view
                $pdf = PDF::loadView('pawnReceiptPrint', [
                    'redeemdata' => $T_redeemdata,
                    'pawnSumData' => $T_sumdata,
                    'pawnDetailsData' => $T_detailsdata,
                    'branchDetails' => $branchData,
                    'companyData' => $companyData
                ]);
    
                // Save the PDF to the public path
                $pdfPath = storage_path('../public/assets/pdf/Redeem_receipt'.$branch_code.'.pdf');
                $pdf->save($pdfPath);
            }
    
            // Generate PDF URL
            $pdfUrl = asset('assets/pdf/Redeem_receipt' . $branch_code . '.pdf');
    
            return back()
                ->with('done', 'The Repawning has been added successfully.')
                ->with('pdfLink', $pdfUrl);
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Something went wrong: ' . $e->getMessage()]);
        }
    }



    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }
}