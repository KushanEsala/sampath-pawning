<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use PDF;
use Illuminate\Http\Request;
use App\Models\itemCondition;
use App\Models\karatage;
use App\Models\Recei_Add;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Company;
use App\Models\TPawnDetails;
use App\Models\TPawnSum;
use App\Models\TRedeemSum;
use App\Models\TOpeningPawnSum;
use App\Models\TOpeningPawnDetails;
use App\Models\branchDel;
use App\Models\TForfeitSum;
use Barryvdh\DomPDF\PDF as DomPDFPDF;

class ForfeitReceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('forfeitReceipt');
    }

    public function store(Request $request)
    {
        $NewForfeit = new TForfeitSum;
        $NewForfeit->Receipt_Number = $request->receipt_number;
        $NewForfeit->Invoice_Number = $request->invoice_number;
        $NewForfeit->Pawn_Receipt_Type = $request->pawn_receipt_type;
        $NewForfeit->Total_Weight = $request->total_weight;
        $NewForfeit->Pawn_Weight = $request->pawn_weight;
        $NewForfeit->Forfeit_Date = $request->forfeit_date;
        $NewForfeit->Forfeit_Number = $request->forfeit_no;
        $NewForfeit->Original_Pawn_Amount = $request->original_pawn_amount;
        $NewForfeit->Payable_Pawn_Amount = $request->original_pawn_amount;
        $NewForfeit->Paid_Interest = $request->paid_interest;
        $NewForfeit->Payable_Interest = $request->payable_interest;
        $NewForfeit->Stamp_Fee = $request->stamp_fee;
        $NewForfeit->Document_Charges = $request->document_charges;
        $NewForfeit->Advance_Balance = $request->advance_balance;
        $NewForfeit->Discount = $request->redeem_discount;
        $NewForfeit->Payable_Total = $request->payable_total;
        $NewForfeit->OC = auth()->user()->username;
        $NewForfeit->BC = auth()->user()->BC;
        $NewForfeit->save();

        $receiptInput_no = $request->receipt_number;
        $Pawn_Receipt_Type = $request->pawn_receipt_type;

        $companyData = Company::latest()->paginate(1);

        if($Pawn_Receipt_Type == "Pawn"){

            TPawnSum::where('Receipt_Number',$request->receipt_number)->update(['isForfeit'=> 1,]);

            $T_sumdata = TPawnSum::where('Receipt_Number', $receiptInput_no)->get();
            $T_detailsdata = TPawnDetails::where('Receipt_Number', $receiptInput_no)->get();

            // Generate the PDF content using a view
            $pdf = PDF::loadView('redeemReceiptPrint', [
                'pawnSumData' => $T_sumdata ,
                'pawnDetailsData' => $T_detailsdata,
                'companyData' => $companyData
            ]);

            // Save the PDF to a temporary file
            $pdfPath = storage_path('../public/assets/pdf/Forfeit_receipt.pdf');
            $pdf->save($pdfPath);

        }elseif($Pawn_Receipt_Type == "Opening_Pawn"){

            TOpeningPawnSum::where('Receipt_Number',$receiptInput_no)->update(['isForfeit'=> 1,]);

            $T_open_sumdata = TOpeningPawnSum::where('Receipt_Number', $receiptInput_no)->get();
            $T_open_detailsdata = TOpeningPawnDetails::where('Receipt_Number', $receiptInput_no)->get();

            // Generate the PDF content using a view
            $pdf = PDF::loadView('redeemReceiptPrint',[
                'pawnSumData' => $T_open_sumdata ,
                'pawnDetailsData' => $T_open_detailsdata,
                'companyData' => $companyData
            ]);

            // Save the PDF to a temporary file
            $pdfPath = storage_path('../public/assets/pdf/Forfeit_receipt.pdf');

            $pdf->save($pdfPath);
        }

        $pdfUrl = asset('public/assets/pdf/Forfeit_receipt.pdf');

        return back()
        ->with('done','The Forfeit has been added')
        ->with("pdfLink", $pdfUrl);
    }



    public function create()
    {
        //
    }


   //receipt Search function
   public function search(Request $request)
   {
       $receiptNo = $request->search_receipt_no;
       $branch_code = auth()->user()->BC;

       $dataTPawnSum = TPawnSum::where('Receipt_Number',$receiptNo)
                       ->where('IsRedeemed', 0)
                       ->where('isForfeit', 0)
                       ->where('BC',$branch_code)
                       ->get();

        $data = $dataTPawnSum;

       if($data->count()>0){

           $cus_nic = $data->first()->Customer_NIC;
           $cus_data = Customer::where('NIC', $cus_nic)->get();

           $receipt_typ = $data->first()->Receipt_Type;
           $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

           $maxRedeemNo = TForfeitSum::where('BC',$branch_code)
                            ->orderBy('Forfeit_Number', 'desc')
                            ->value('Forfeit_Number');

           $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

           $pawn_type = "Pawn";

           return view('forfeitSearch')
           ->with("maxRedeem", $maxRedeemNos)
           ->with('customerData', $cus_data)
           ->with('receiptTypeData', $receipt_data)
           ->with('pawnType', $pawn_type)
           ->with('receiptData', $data);
       }else{
           return response()->json([
               'status'=>'not_found'
           ]);
       }
   }

    //invoice Search function
    public function searchInvoice(Request $request)
    {
        $invoiceNo = $request->search_invoice_no;
        $branch_code = auth()->user()->BC;

        $TOpeningPawnSumdata = TOpeningPawnSum::where('Invoice_Number',$invoiceNo)
                                ->where('IsRedeemed', 0)
                                ->where('isForfeit', 0)
                                ->where('BC',$branch_code)
                                ->get();

        $data = $TOpeningPawnSumdata;

        if($data->count()>0){

            $cus_nic = $data->first()->Customer_NIC;
            $cus_data = Customer::where('NIC', $cus_nic)->get();

            $receipt_typ = $data->first()->Receipt_Type;
            $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

            $maxRedeemNo = TForfeitSum::where('BC',$branch_code)
                                    ->orderBy('Forfeit_Number', 'desc')
                                    ->value('Forfeit_Number');

            $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

            $pawn_type = "Opening_Pawn";

            return view('forfeitSearch')
            ->with("maxRedeem", $maxRedeemNos)
            ->with('customerData', $cus_data)
            ->with('receiptTypeData', $receipt_data)
            ->with('pawnType', $pawn_type)
            ->with('receiptData', $data);
        }else{
            return response()->json([
                'status'=>'not_found'
            ]);
        }
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
