<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use Datatables;
class CategoryController extends Controller
{

    public function index()
    {
        $itemCategory = Category::all();
        return view('Category')->with("itemCategoryData" , $itemCategory);

    }

    public function addCategory(Request $request)
    {

        $CategoryId = $request->id;

        $Category   =   Category::updateOrCreate(
                    [
                     'id' => $CategoryId
                    ],
                    [
                    'category' => $request->category,
                    ]);

        return Response()->json($Category);
    }

    public function editCategory(Request $request)
    {
        $where = array('id' => $request->id);
        $Category  = Category::where($where)->first();

        return Response()->json($Category);
    }

    public function deleteCategory(Request $request)
    {
        $Category = Category::where('id',$request->id)->delete();

        return Response()->json($Category);
    }


    public function create(Request $request)
    {
        $request->validate([
             'categoryName'=>'required | max:80 |unique:categories,category',
        ]);

        $Category = new Category;
        $Category->category = $request->categoryName;
        $Category->save();

        return response()->json([
            'status'=>'success',
        ]);
    }

    public function delete(Request $request)
    {
        Category::find($request->id)->delete();
        return response()->json([
            'status'=>'success',
        ]);
    }

    public function show($id)
    {
    }

    public function edit($id)
    {
    }

    public function update(Request $request)
    {
        $request->validate([
             'up_categoryName'=>'required | max:80',
        ]);

        Category::where('id',$request->up_id)->update([
            'category'=> $request->up_categoryName,
        ]);

        return response()->json([
            'status'=>'success',
        ]);
    }

    public function destroy($id)
    {
    }
}
