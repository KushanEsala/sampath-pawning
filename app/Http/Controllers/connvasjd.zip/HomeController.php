<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\TPawnSum;
use App\Models\TRedeemSum;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $branch_code = auth()->user()->BC;
        
        $query = TPawnSum::all()
                ->where('BC', $branch_code);

        $query2 = TRedeemSum::all()
                ->where('BC', $branch_code);
        
        $TotalPawn = $query->count();
        $TotalRedeem = $query2->count();
        $PawningTotal = $query->sum('Amount');
        $Pawningpayemt = number_format($PawningTotal, 2);

        $RedeemTotal = $query2->sum('Payable_Pawn_Amount');
        $Redeempayment = number_format($RedeemTotal, 2);

        $InterestTotal = $query->sum('Interest');
        $Interest = number_format($InterestTotal, 2);

        //Showing Pawning Customer Details in the Home page
        $Pawningdetails = TPawnSum::latest()
        ->where('BC',$branch_code)
        ->paginate(6);

        //Showing Pawning Customer Details in the Home page
        $Redeemdetails = TRedeemSum::latest()
        ->where('BC',$branch_code)
        ->paginate(6);

        return view('home', compact('TotalPawn','TotalRedeem','Pawningpayemt','Redeempayment','Interest'))
        //Showing Customer Details in the Home page-23
        ->with('customerdetails',$Pawningdetails)

        //Showing Redeem Customer Details in the Home page-23
        ->with('RedeemCustomer',$Redeemdetails);
    }

}
