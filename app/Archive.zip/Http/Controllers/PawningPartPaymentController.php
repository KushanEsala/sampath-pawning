<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use PDF;
use Illuminate\Http\Request;
use App\Models\itemCondition;
use App\Models\karatage;
use App\Models\Recei_Add;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Company;
use App\Models\TPawnDetails;
use App\Models\TPawnSum;
use App\Models\TRedeemSum;
use App\Models\TPawnPayment;
use App\Models\TOpeningPawnSum;
use App\Models\TOpeningPawnDetails;
use App\Models\branchDel;
use App\Models\TPawnTrans;
use Carbon\Carbon;

class PawningPartPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $branch_code = auth()->user()->BC;

        $maxRedeemNo = TPawnPayment::where('BC',$branch_code)
        ->orderBy('Redeem_Number', 'desc')
        ->value('Redeem_Number');

        $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);
        $branchData = branchDel::all();

        return view('pawningPartPayment')
        ->with("branch",  $branchData)
        ->with("maxRedeem", $maxRedeemNos);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
      public function PartpaymentSearch(Request $request)
    {
        $receiptNo = $request->search_receipt_no;
        $branchReceipt = $request->branch;
        $branch_code = auth()->user()->BC;

        $dataTPawnSum = TPawnSum::where('Receipt_Number',$receiptNo)
                        ->where('IsRedeemed', 0)
                        ->where('isForfeit', 0)
                         ->where('BC',  $branch_code)
                        ->get();

        $data = $dataTPawnSum;

        if($data->count()>0){
            $branch_code = auth()->user()->BC;
            $cus_nic = $data->first()->Customer_NIC;
            $cus_data = Customer::where('NIC', $cus_nic)
                        ->get();

            $receipt_typ = $data->first()->Receipt_Type;
            $receipt_data = Recei_Add::where('receiptname', $receipt_typ)->get();

            $maxRedeemNo = TPawnPayment::where('BC',$branch_code)
            ->orderBy('Redeem_Number', 'desc')
            ->value('Redeem_Number');

            $maxRedeemNos = str_pad($maxRedeemNo, 4, '0', STR_PAD_LEFT);

            $pawn_type = "Pawn";

            return view('searchPartPayment')
            ->with("maxRedeem", $maxRedeemNos)
            ->with('customerData', $cus_data)
            ->with('receiptTypeData', $receipt_data)
            ->with('pawnType', $pawn_type)
            ->with('receiptData', $data);
        }else{
            return response()->json([
                'status'=>'not_found'
            ]);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
      public function AddPartPayment(Request $request)
      {
        $NewRedeem = new TPawnPayment;
        $NewRedeem->Receipt_Number = $request->receipt_number;
        $NewRedeem->Invoice_Number = $request->invoice_number;
        $NewRedeem->Ticket_Number = $request->ticket_number;
        $NewRedeem->Customer_Name = $request->Customer_Name;
        $NewRedeem->Customer_NIC = $request->Customer_NIC;
        $NewRedeem->Pawn_Receipt_Type = $request->pawn_receipt_type;
        $NewRedeem->Redeem_Date = $request->redeem_date;
        $NewRedeem->Redeem_Number = $request->redeem_no;
        $NewRedeem->Total_Weight = $request->sum_total_weight;
        $NewRedeem->Pawn_Weight = $request->sum_pawn_weight;
        $NewRedeem->Original_Pawn_Amount = $request->original_pawn_amount;
        $NewRedeem->Payable_Pawn_Amount = $request->Payable_Pawn_Amount;
        $NewRedeem->Paid_Interest = $request->paid_interest;
        $NewRedeem->Payable_Interest = $request->payable_interest;
        $NewRedeem->Stamp_Fee = $request->stamp_fee;
        $NewRedeem->Document_Charges = $request->document_charges;
        $NewRedeem->Advance_Balance = $request->advance_balance;
        $NewRedeem->Advance_Payment = $request->advance_payment;  
        $NewRedeem->Discount = $request->redeem_discount;
        $NewRedeem->Payable_Total = $request->payable_total;
        $NewRedeem->OC = auth()->user()->username;
        $NewRedeem->BC = auth()->user()->BC;
        $NewRedeem->save();


  
    
        $branch_code = auth()->user()->BC;
        $receiptInput_no = $request->receipt_number;
        $Pawn_Receipt_Type = $request->pawn_receipt_type;

    
        $companyData = Company::latest()->paginate(1);
        $branchData = branchDel::where('bccode', $branch_code)->paginate(1);
    
        $receipt_advanceAmount = $request->advance_payment;
        $receipt_Interest = $request->paid_interest;
        $Balance = $request->BalanceInterest;
        $pawndate = $request->redeem_date;

    
        $advancePayments = TPawnSum::where('Receipt_Number', $request->receipt_number)
                                    ->where('BC',$branch_code)
                                    ->get();
    
        $amounts = $advancePayments->pluck('Pawn_Amount'); // Extract all Amount values  
        $totalAmount = $amounts->sum(); // Sum all values in the collection

        $amountsinterest = $advancePayments->pluck('interest_Paid'); // Extract all Amount values 
        $totalAmountinterest = $amountsinterest->sum(); // Sum all values in the collection

        $BalanceInterest = $advancePayments->pluck('BalanceInterest'); // Extract all Amount values 
        $totalBalanceInterest = $BalanceInterest->sum(); // Sum all values in the collection


        if ($Balance > 0) {
            $totalAdvancePayment = $totalAmount + $Balance;
        } else {
          $totalAdvancePayment = $totalAmount - $receipt_advanceAmount;
        }
        $totalInterest = $receipt_Interest + $totalAmountinterest;
        $Interest = $Balance + $totalBalanceInterest;

        $validyed_type = $request->validyed_type;

        $final_date_raw =  $request->redeem_date;

        // Convert to Carbon date
        $carbon_date = Carbon::parse($final_date_raw);

        // Add months
        $final_date = $carbon_date->addMonths($validyed_type);

        // If needed as string (e.g., for display or DB save)
        $final_date_string = $final_date->toDateString(); // format: YYYY-MM-DD

              
    
            // Ensure interest balance is not negative
            $interest_Balance = $Balance < 0 ? 0 : $Balance;

            // Create a new Part Payment transaction
            $TPawnTrans = new TPawnTrans;
            $TPawnTrans->Customer_NIC = $request->Customer_NIC;              // Customer NIC
            $TPawnTrans->Customer_Name = $request->Customer_Name;            // Customer Name
            $TPawnTrans->code = $request->receipt_number;                    // Receipt Number
            $TPawnTrans->trans_no = $request->redeem_no;                     // Redeem Transaction Number
            $TPawnTrans->trans_type = "PART_PAYMENT";                        // Transaction Type
            $TPawnTrans->trans_amount = $request->redeem_total;              // Redeem Total Amount
            $TPawnTrans->dDate = $request->redeem_date;                      // Transaction Date
            $TPawnTrans->Cr_amount = 0;                                      // Credit Amount (0 for part payment)
            $TPawnTrans->Dr_amount = $request->payable_total;                // Debit Amount (Total payable)
            $TPawnTrans->Paided_Interest = $request->paid_interest;          // Paid Interest
            $TPawnTrans->Pawn_Amount = $request->original_pawn_amount;       // Original Pawn Amount
            $TPawnTrans->payable_total = $request->payable_total;            // Total Payable
            $TPawnTrans->Paided_Captional = $request->advance_payment;       // Advance Payment (Paid Principal)
            $TPawnTrans->Extend_Date = $final_date_string;                   // Next Due/Extend Date
            $TPawnTrans->interest_Balance = $interest_Balance;               // Remaining Interest
            $TPawnTrans->OC = auth()->user()->username;                      // Operator Code (Logged-in User)
            $TPawnTrans->BC = auth()->user()->BC;                            // Branch Code (User's Branch)
            $TPawnTrans->save();    
            
                        // Fetch all rate slabs from the DB once
            $rates = Recei_Add::orderByDesc('pawn_amount')->get();

            // Initialize default values
            $receiptname = null;
            $interest = null;
            $Pawn_Amount_partpayment = $request->original_pawn_amount;
            $payable_total_partpayment = $request->payable_total; 
            $totalRepawnPayment = $Pawn_Amount_partpayment - $payable_total_partpayment;


            foreach ($rates as $rate) {
                if ($totalRepawnPayment >= 100000 && $rate->pawn_amount >= 100000) {
                    $receiptname = $rate->receiptname;
                    $interest = $rate->rate3;
                    break;
                } elseif ($totalRepawnPayment >= 50000 && $totalRepawnPayment <= 99999 && $rate->pawn_amount >= 50000 && $rate->pawn_amount <= 99999) {
                    $receiptname = $rate->receiptname;
                    $interest = $rate->rate3;
                    break;
                } elseif ($totalRepawnPayment < 50000 && $rate->pawn_amount < 50000) {
                    $receiptname = $rate->receiptname;
                    $interest = $rate->rate3;
                    break;
                }
            }

            
       TPawnSum::where('Receipt_Number', $request->receipt_number)
                    ->where('BC',$branch_code)
                    ->update([
                        'Pawn_Amount' => $totalAdvancePayment,
                        'RePawning_amount' => $totalAdvancePayment,
                        'Advance_Payment' => $receipt_advanceAmount,
                        'interest_Paid' => $totalInterest,
                        'BalanceInterest' => $Interest,
                        'Pawn_Date' => $pawndate,
                        'Receipt_Type' => $receiptname, 
                        'Interest_Rate' => $interest, 
                        'Valid_Period'=>$validyed_type,
                        'Final_date'=> $final_date_string,
                        'RePawning_date' => $pawndate,
                    ]);
    

                    
           $T_sumdata = TPawnSum::where('Receipt_Number', $receiptInput_no)
                                    ->where('BC',$branch_code)
                                    ->get();
                                
            $T_detailsdata = TPawnDetails::where('Receipt_Number', $receiptInput_no)
                                        ->where('BC',$branch_code)
                                        ->get();
                                
            $T_redeemdata  = TPawnPayment::where('Redeem_Number', $request->redeem_no)
                                        ->where('Pawn_Receipt_Type',$request->pawn_receipt_type)
                                        ->where('BC',$branch_code)
                                        ->get();                

                // Generate the PDF content using a view
                $pdf = PDF::loadView('partpaymentReceiptPrint', [
                    'pawnSumData' => $T_sumdata ,
                    'pawnDetailsData' => $T_detailsdata,
                    'redeemdata' => $T_redeemdata,
                    'branchDetails' => $branchData,
                    'companyData' => $companyData
                ]);

                $pdfPath = storage_path('../public/assets/pdf/Redeem_receipt'.$branch_code.'.pdf');
                $pdf->save($pdfPath);
                 $pdfUrl = asset('../public/assets/pdf/Redeem_receipt' . $branch_code . '.pdf');
    
        return back()
            ->with('done', 'The Redeem has been added')
            ->with("pdfLink", $pdfUrl);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}