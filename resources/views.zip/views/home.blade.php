{{-- @extends('layouts.app') --}}
@extends('layouts.topnavbar')
@extends('layouts.sidebar')
@section('content')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Dashboard</title>

</head>

<body class="nk-body bg-lighter npc-default has-sidebar no-touch nk-nio-theme">
    <div class="main-wrapper">

        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="row">

                     {{-- Showing Pawning Total and Receipt Count --}}
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card">
                        <div class="shadow p-3 mb-1 bg-body-tertiary rounded">
                            <div class="card-body">
                                <div class="dash-widget-header">
                                    <span class="dash-widget-icon bg-1">
                                        <i class="fas fa-dollar-sign"></i>
                                    </span>
                                    <div class="dash-count">
                                        <div class="dash-title">TOTAL PAWNING</div>
                                        <div class="dash-counts">
                                            <div class="dash-title">Pawning Receipt: {{$TotalPawn}}</div>
                                        <h5>{{$Pawningpayemt}}</h5>
                                        </div>

                                    </div>
                                </div>
                                <div class="progress progress-sm mt-3">
                                    <div class="progress-bar bg-5" role="progressbar" style="width: 75%"
                                        aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>

                                   {{-- Showing Redeem Total and Receipt Count --}}
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card">
                        <div class="shadow p-3 mb-1 bg-body-tertiary rounded">
                            <div class="card-body">
                                <div class="dash-widget-header">
                                    <span class="dash-widget-icon bg-2">
                                        <i class="fas fa-shopping-cart"></i>
                                    </span>
                                    <div class="dash-count">
                                        <div class="dash-title">TOTAL REDEEM</div>
                                        <div class="dash-counts">
                                            <div class="dash-title">Redeem Receipt: {{$TotalRedeem}}</div>
                                        <h5>{{$Redeempayment }}</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-3">
                                    <div class="progress-bar bg-6" role="progressbar" style="width: 65%"
                                        aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>

                    {{-- Showing Interest --}}
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card">
                        <div class="shadow p-3 mb-1 bg-body-tertiary rounded">
                            <div class="card-body">
                                <div class="dash-widget-header">
                                    <span class="dash-widget-icon bg-3">
                                        <i class="fas fa-exclamation"></i>
                                    </span>
                                    <div class="dash-count">
                                        <div class="dash-title">INTEREST</div>
                                        <div class="dash-counts">
                                            <h5>{{$Interest}}</h5>
                                            <br>
                                        </div>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-3">
                                    <div class="progress-bar bg-7" role="progressbar" style="width: 85%"
                                        aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-xl-7 d-flex">
                        <div class="card flex-fill">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="card-title">Pawning & Redeem Analytics</h5>
                                    <div class="dropdown">
                                        <button class="btn btn-white btn-sm dropdown-toggle" type="button"
                                            id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                            Monthly
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Daliy</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Weekly</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Monthly</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Yearly</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between flex-wrap flex-md-nowrap">
                                    <div class="w-md-100 d-flex align-items-center mb-3 flex-wrap flex-md-nowrap">
                                        <div>
                                            <span>Pawning Total </span>
                                            <p class="h5 text-secondary me-5">Rs:{{$Pawningpayemt}}</p>
                                        </div>
                                        <div>

                                            <span>Redeem Total </span>
                                            <p class="h5 text-info me-5">Rs:{{$Redeempayment}}</p>
                                        </div>
                                        <div>
                                            <span>Interest</span>
                                            <p class="h5 text-success me-5">Rs:{{$Interest}}</p>
                                        </div>

                                    </div>
                                </div>
                                <div id="sales_chart"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5 d-flex">
                        <div class="card flex-fill">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="card-title">Pawning & Redeem Daily Analytics</h6>
                                    <div class="dropdown">
                                        <button class="btn btn-white btn-sm dropdown-toggle" type="button"
                                            id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                            Monthly
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Daliy</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Weekly</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Monthly</a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" class="dropdown-item">Yearly</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div id="invoice_chart"></div>
                                <div class="text-center text-muted">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="mt-4">
                                                <p class="mb-2 text-truncate"><i
                                                        class="fas fa-circle text-primary me-1"></i> Pawning</p>
                                                <h5>{{$Pawningpayemt | number_format(2)}}</h5>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="mt-4">
                                                <p class="mb-2 text-truncate"><i
                                                        class="fas fa-circle text-success me-1"></i> Redeem</p>
                                                <h5>{{$Redeempayment}}</h5>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="mt-4">
                                                <p class="mb-2 text-truncate"><i
                                                        class="fas fa-circle text-danger me-1"></i> Interest</p>
                                                <h5>{{$Interest | number_format(2)}}</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title">Pawning payment</h5>
                                    </div>
                                    <div class="col-auto">
                                        <a href="invoices.html" class="btn-right btn btn-sm btn-outline-primary">
                                            View All
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="progress progress-md rounded-pill mb-3">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 47%"
                                            aria-valuenow="47" aria-valuemin="0" aria-valuemax="100"></div>
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 28%"
                                            aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 15%"
                                            aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 10%"
                                            aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-success me-1"></i> Paid
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-warning me-1"></i> Unpaid
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-danger me-1"></i> Overdue
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-info me-1"></i> Draft
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-stripped table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Receipt Number</th>
                                                <th>Customer NIC</th>
                                                <th>Customer Name</th>
                                                <th>Customer Address</th>
                                                <th>Customer Phone</th>
                                                <th>Receipt Type</th>
                                                
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Total Amount</th>
                                                <th>Interest</th>
                                                <th class="text-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($customerdetails as $CustomerData)
                                            <tr>
                                                 <td>{{ $CustomerData->Receipt_Number}}</td>
                                                <td>{{ $CustomerData->Customer_NIC}}" </td>
                                                <td>{{ $CustomerData->Customer_Name}}</td>
                                                <td>{{ $CustomerData->Customer_Address}}</td>
                                                <td>{{ $CustomerData->Customer_Phone}} </td>
                                                <td>{{ $CustomerData->Receipt_Type}}</td>
                                               
                                                <td>{{ $CustomerData->Receipt_Date}}</td>
                                                <td>{{ $CustomerData->Amount}}</td>
                                                <td>{{ $CustomerData->Total_Amount}}</td>
                                                <td>{{ $CustomerData->Interest}}</td>
                                                <td class="text-right">
                                                    <div class="dropdown dropdown-action">
                                                        <a href="#" class="action-icon dropdown-toggle"
                                                            data-bs-toggle="dropdown" aria-expanded="false"><i
                                                                class="fas fa-ellipsis-h"></i></a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="edit-invoice.html"><i
                                                                    class="far fa-edit me-2"></i>Edit</a>
                                                            <a class="dropdown-item" href="view-invoice.html"><i
                                                                    class="far fa-eye me-2"></i>View</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-trash-alt me-2"></i>Delete</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-check-circle me-2"></i>Mark as
                                                                sent</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-paper-plane me-2"></i>Send Invoice</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-copy me-2"></i>Clone Invoice</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title">Redeem Payment</h5>
                                    </div>
                                    <div class="col-auto">
                                        <a href="estimates.html" class="btn-right btn btn-sm btn-outline-primary">
                                            View All
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="progress progress-md rounded-pill mb-3">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 39%"
                                            aria-valuenow="39" aria-valuemin="0" aria-valuemax="100"></div>
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 35%"
                                            aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 26%"
                                            aria-valuenow="26" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-success me-1"></i> Sent
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-warning me-1"></i> Draft
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-circle text-danger me-1"></i> Expired
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Receipt_Number</th>
                                                <th>Redeem_Date</th>
                                                <th>Redeem_Number</th>
                                                <th>Original_Pawn_Amount</th>
                                                <th>Payable_Pawn_Amount</th>
                                                <th>Paid_Interest</th>
                                                <th>Payable_Interest</th>
                                                <th>Stamp_Fee</th>
                                                <th>Document_Charges</th>
                                                <th>Advance_Balance</th>
                                                <th>Discount</th>
                                                <th>Payable_Total</th>
                                                <th class="text-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($RedeemCustomer as $RadeemData)
                                            <tr>
                                                <td>{{ $RadeemData->Receipt_Number}}</td>
                                                <td>{{ $RadeemData->Redeem_Date}}</td>
                                                <td>{{ $RadeemData->Redeem_Number}}</td>
                                                <td>{{ $RadeemData->Original_Pawn_Amount}}</td>
                                                <td>{{ $RadeemData->Payable_Pawn_Amount}}</td>
                                                <td>{{ $RadeemData->Paid_Interest}}</td>
                                                <td>{{ $RadeemData->Payable_Interest}}</td>
                                                <td>{{ $RadeemData->Stamp_Fee}}</td>
                                                <td>{{ $RadeemData->Document_Charges}}</td>
                                                <td>{{ $RadeemData->Advance_Balance}}</td>
                                                <td>{{ $RadeemData->Discount}}</td>
                                                <td>{{ $RadeemData->Payable_Total}}</td>
                                                <td class="text-right">
                                                    <div class="dropdown dropdown-action">
                                                        <a href="#" class="action-icon dropdown-toggle"
                                                            data-bs-toggle="dropdown" aria-expanded="false"><i
                                                                class="fas fa-ellipsis-h"></i></a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="edit-invoice.html"><i
                                                                    class="far fa-edit me-2"></i>Edit</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-trash-alt me-2"></i>Delete</a>
                                                            <a class="dropdown-item" href="view-estimate.html"><i
                                                                    class="far fa-eye me-2"></i>View</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-file-alt me-2"></i>Convert to
                                                                Invoice</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-check-circle me-2"></i>Mark as
                                                                sent</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-paper-plane me-2"></i>Send
                                                                Estimate</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-check-circle me-2"></i>Mark as
                                                                Accepted</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                                    class="far fa-times-circle me-2"></i>Mark as
                                                                Rejected</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/feather.min.js"></script>
    <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/plugins/apexchart/apexcharts.min.js"></script>
    <script src="assets/plugins/apexchart/chart-data.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
@endsection
