<head>
    <style>
        @import 'https://fonts.googleapis.com/css?family=Open+Sans:600,700';


.rwd-table {
  margin: auto;
  min-width: 300px;
  max-width: 75%;
  border-collapse: collapse;
  font-family: 'Open Sans', sans-serif;
}


.rwd-table tr:first-child {
  border-top: none;
  background: #428bca;
  color: #fff;
}

.rwd-table tr {
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  background-color: #f5f9fc;
}

.rwd-table tr:nth-child(odd):not(:first-child) {
  background-color: #ebf3f9;
}

.rwd-table th {
  display: none;
}

.rwd-table td {
  display: block;
}

.rwd-table td:first-child {
  margin-top: .5em;
}

.rwd-table td:last-child {
  margin-bottom: .5em;
}

.rwd-table td:before {
  content: attr(data-th) ": ";
  font-weight: bold;
  width: 120px;
  display: inline-block;
  color: #000;
}

.rwd-table th,
.rwd-table td {
  text-align: left;
}

.rwd-table {
  color: #333;
  border-radius: .4em;
  overflow: hidden;
}

.rwd-table tr {
  border-color: #bfbfbf;
}

.rwd-table th,
.rwd-table td {
  padding: .5em 1em;
}
@media screen and (max-width: 601px) {
  .rwd-table tr:nth-child(2) {
    border-top: none;
  }
}
@media screen and (min-width: 600px) {
  .rwd-table tr:hover:not(:first-child) {
    background-color: #d8e7f3;
  }
  .rwd-table td:before {
    display: none;
  }
  .rwd-table th,
  .rwd-table td {
    display: table-cell;
    padding: .25em .5em;
  }
  .rwd-table th:first-child,
  .rwd-table td:first-child {
    padding-left: 0;
  }
  .rwd-table th:last-child,
  .rwd-table td:last-child {
    padding-right: 0;
  }
  .rwd-table th,
  .rwd-table td {
    padding: 1em !important;
  }
}

.container {
  display: block;
  text-align: center;
  width: 100%; /* Set the width to 80% of its parent container */
  max-width: 1500px; /* Set a maximum width to prevent it from growing too wide */
  margin: 0 auto; /* Center the container horizontally */
}

    </style>
    
</head>
<div class="col ">
    <div class="row">
        <div class="col">
            <input type="hidden" id="operator" name="operator" value="{{ Auth::user()->name }}" required>

            @foreach ($receiptData as $receipt)
            <input type="hidden" id="r_number" name="r_number" value="{{ $receipt['Receipt_Number'] }}" required>
            <input type="hidden" id="i_number" name="i_number" value="{{ $receipt['Invoice_Number'] }}">
            <input type="hidden" id="t_number" name="t_number" value="{{ $receipt['Ticket_Number'] }}">

            <input type="hidden" id="sum_total_weight" name="sum_total_weight" value="{{ $receipt['Total_Weight'] }}">
            <input type="hidden" id="sum_pawn_weight" name="sum_pawn_weight" value="{{ $receipt['Pawn_Weight'] }}">
            @endforeach


            <label for="receipt_type">Receipt Type :
                <input class="form-control"  type="text" placeholder="Receipt type"
                    name="receipt_type"
                    @foreach ($receiptData as $receipt)
                    value="{{$receipt['Receipt_Type']}}"
                    @endforeach
                    id="receipt_type" readonly/>
            </label>
        </div>
        <div class="col">
                <label for="date">Date :
                    <input class="form-control" type="date"
                    id="date"
                    @foreach ($receiptData as $receipt)
                    value="{{ $receipt['Pawn_Date'] }}"
                    @endforeach
                    name="redeem_date" required>
                </label>
        </div>
        <div class="col">
            <label for="redeem_no">Redeem Number :
                <input class="form-control" type="text" placeholder="Redeem Number:"
                value="{{ $maxRedeem+1 }}"
                id="redeem_no" name="redeem_no" required>
            </label>
        </div>
        <div class="col">
            @if($pawnType == "Pawn")
            <label for="pawn_receipt_type"><span class="text-success">Pawn Receipt Type :</span>
                <input class="form-control text-success" type="text" placeholder="Pawn Receipt Type:"
                value="{{ $pawnType }}"
                id="pawn_receipt_type" name="pawn_receipt_type" required readonly>
            </label>
            @elseif($pawnType == "Opening_Pawn")
            <label for="pawn_receipt_type"><span class="text-primary">Pawn Receipt Type :</span>
                <input class="form-control text-primary" type="text" placeholder="Pawn Receipt Type:"
                value="{{ $pawnType }}"
                id="pawn_receipt_type" name="pawn_receipt_type" required readonly>
            </label>

            @endif
        </div>
    </div>
</div>
<div class="row">
    <!-- Receipt Info Table -->
    <div class="col-md-6">
        <h5 class="mt-3 mb-2">Receipt Info</h5>
        <table class="table table-bordered text-center" id="dynamicAdded" style="width: 100%">
            <thead class="thead-light">
                {{-- <tr>
                    <th>Final Date</th>
                    <td>
                        <p id="date-final">
                            @foreach ($receiptData as $receipt)
                            {{ $receipt['Valid_Period'] }}
                            @endforeach
                        </p>
                    </td>
                    <th>Receipt Date Time</th>
                    <td>
                        <p>
                            @foreach ($receiptData as $receipt)
                            {{ $receipt['Pawn_Date'] }}
                            @endforeach
                        </p>
                    </td>
                    <th>Period (Days)</th>
                    <td>
                        <p id="date-period"></p>
                    </td>
                </tr> --}}
           @php
    // Initialize the variable before the loop
    $finalDueDate = null;
@endphp

@foreach ($receiptData as $receipt)
    @php
        $receiptDate = new DateTime($receipt['Pawn_Date']);
        $validPeriod = isset($receipt['Valid_Period']) && $receipt['Valid_Period'] !== null ? (int)$receipt['Valid_Period'] : 0;
        $receiptDate->modify("+{$validPeriod} months");
        $dueDate = $receiptDate->format('Y-m-d');
        
        // Store the latest due date
        if ($finalDueDate === null || $dueDate > $finalDueDate) {
            $finalDueDate = $dueDate;
        }
    @endphp
@endforeach

<tr>
    <th>Final Date</th>
    <td>
        <p id="date-final">
            {{ $finalDueDate }}
        </p>
    </td>
</tr>

            
                
                <tr>
                    <th>Receipt Date Time</th>
                    @foreach ($receiptData as $receipt)
                    <td><p> {{ $receipt['Pawn_Date'] }}</p></td>
                    @endforeach
                </tr>
                <tr>
                    <th>Period (Days)</th>
                    <td>
                        <p id="date-period"></p>
                    </td>
                </tr>
            </thead>
        </table>
    </div>

    <!-- Customer Info Table -->
    <div class="col-md-6">
        <h5 class="mt-3 mb-2">Customer Info</h5>
        <table class="table table-bordered text-center" style="width: 100%">
            <thead>
                <tr>
                    <th>Name</th>
                    @foreach ($customerData as $customer)
                    <td><h7>{{ $customer['First_name'] }} {{ $customer['Middle_name'] }} {{ $customer['Last_name'] }}</h7></td>
                    @endforeach
                </tr>
                <tr>
                    <th>Address</th>
                    @foreach ($customerData as $customer)
                    <td><h6>{{ $customer['Address_1'] }}</h5></td>
                    @endforeach
                </tr>
                <tr>
                    <th>NIC</th>
                    @foreach ($customerData as $customer)
                    <td><h5>{{ $customer['NIC'] }}</h5></td>
                    @endforeach
                </tr>
                <tr>
                    <th>Contact</th>
                    @foreach ($customerData as $customer)
                    <td><h5>{{ $customer['Contact_1'] }}</h5></td>
                    @endforeach
                </tr>
            </thead>
        </table>
    </div>
</div>



<input type="hidden"  class="form-control text-center" value="{{ $customer['First_name'] }} {{ $customer['Last_name'] }}" name="Customer_Name" id="Customer_Name">
<input type="hidden" class="form-control text-center" value="{{ $customer['NIC'] }}" id="Customer_NIC" name="Customer_NIC">



<br>
<div class="row" style="align-content: center;">
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12">
                <button class="btn btn-outline-info form-control" type="button"
                data-bs-toggle="modal" data-bs-target="#viewArticleDetailsModel">
                <i class="far fa-eye me-1"></i>
                    View Article Details
                </button>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="col-md-12">
            <button class="btn btn-outline-info form-control" type="button"
            data-bs-toggle="modal" data-bs-target="#viewPaymentHistoryModel">
            <i class="far fa-eye me-1"></i>
                Payment History
            </button>
        </div>
    </div>
</div>
<br>
<h5 class="mt-3 mb-2">Repawning Details</h5>
<table class="table table-bordered text-center" id="dynamicAdded">
    <tbody class="thead-light">
        <tr>
            <th>Pawn Article Total Value </th>
            <td>
                @foreach ($receiptData as $receipt)
                <p>
                    <input class="form-control text-center"  type="text" placeholder="Original Pawn Amount"
                        value="{{ number_format($receipt['Total_Amount'], 2) }}" readonly/>

                    <input type="hidden"
                    name="original_pawn_amount"
                    value="{{ $receipt['Total_Amount'] }}"
                    id="original_pawn_amount" readonly/>
                </p>
                @endforeach
            </td>
        </tr>
        <tr>
           
            <th>Original Pawn Amount</th>
            <td>
                @foreach ($receiptData as $receipt)
                <p>
                    <input class="form-control text-center"  type="text" placeholder="Original Pawn Amount"
                        value="{{ number_format($receipt['Amount'], 2) }}" readonly/>

                    <input type="hidden"
                    name="original_pawn_amount"
                    value="{{ $receipt['Amount'] }}"
                    id="original_pawn_amount" readonly/>
                </p>
                @endforeach
            </td>
        </tr>
        <tr>
           
            <th>Current Pawn Amount</th>
            <td>
                @foreach ($receiptData as $receipt)
                <p>
                    <input class="form-control text-center"  type="text" placeholder="Original Pawn Amount"
                        value="{{ number_format($receipt['Pawn_Amount'], 2) }}" readonly/>
                </p>
                @endforeach
            </td>
        </tr>
        <tr>
            <th>Paid Interest</th>
            <td>
                <p>
                    <input class="form-control text-center" id="interest" type="text" placeholder="Paid Interest"
                    name="paid_interest" value="" readonly/>
                </p>
            </td>
        </tr>
        <tr>
            <th>Stampduty</th>
            <td>
                <p>
                    <input class="form-control text-center" id="stampduty" type="text" placeholder="Stampduty"
                    name="stampduty" value="" readonly/>
                </p>
            </td>
        </tr>
        <tr>
            <th>Service Charges</th>
            <td>
                <p>
                    <input class="form-control text-center" id="document_charges" type="text" placeholder="Document Charges"
                    name="document_charges" value="" readonly/>
                </p>
            </td>
        </tr>
    </tbody>
</table>
<br>
<br>
<div class="container">
    <div class="table-responsive">
    <table  class="rwd-table">
        <tbody>
            <tr style="background-color: #428bca">
                <th width = >01 Months</th>
                <th>02 Months</th>
                <th>03 Months</th>
                <th>04 Months</th>
                <th>05 Months</th>
                <th>06 Months</th>
                <th>07 Months</th>
                <th>08 Months</th>
                <th>09 Months</th>
                <th>10 Months</th>
                <th>11 Months</th>
                <th>12 Months</th>
              </tr> 
              <tr> 
                
                <td id="output1"><input type="text" id="Interest1" style="outline: #ebf3f9" readonly></td>
                <td id="output2"><input type="text" id="Interest2" style="outline: #ebf3f9" readonly></td>
                <td id="output3"><input type="text" id="Interest3" style="outline: #ebf3f9" readonly></td>
                <td id="output4"><input type="text" id="Interest4" style="outline: #ebf3f9" readonly></td>
                <td id="output5"><input type="text" id="Interest5" style="outline: #ebf3f9" readonly></td>
                <td id="output6"><input type="text" id="Interest6" style="outline: #ebf3f9" readonly></td>
                <td id="output7"><input type="text" id="Interest7" style="outline: #ebf3f9" readonly></td>
                <td id="output8"><input type="text" id="Interest8" style="outline: #ebf3f9" readonly></td>
                <td id="output9"><input type="text" id="Interest9" style="outline: #ebf3f9" readonly></td>
                <td id="output10"><input type="text" id="Interest10" style="outline: #ebf3f9" readonly></td>
                <td id="output11"><input type="text" id="Interest11" style="outline: #ebf3f9" readonly></td>
                <td id="output12"><input type="text" id="Interest12" style="outline: #ebf3f9" readonly></td>
              </tr>
            </tbody>
    </table>
    
    </div>
    </div>
<br>


{{-- Functions for date and time  calculation --}}
<script>
    $(document).ready(function () {

        // form default date set for today
        document.getElementById('date').valueAsDate = new Date();

        calculateFinalDate();
        interestCalculations();

        //getting document charges
        let doc_chargers = 0 ;
        let stampduty = 0 ;
        let s_charge_less = 0;
        let s_charge_greater= 0;

            @foreach ($receiptTypeData as $receiptType)
                doc_chargers = {{ $receiptType['documentCharges'] }};
                stampduty = {{ $receiptType['stampduty'] }};
                s_charge_less = parseFloat({{ $receiptType['s_charge_less'] }}) || 0;
                s_charge_greater = parseFloat({{ $receiptType['s_charge_greater'] }}) || 0;
            @endforeach;

            // $('#document_charges').val(doc_chargers);

            let p_amount = parseFloat( {{  $receiptData[0]['Amount'] }} ) || 0;
            if(p_amount < 25000){
                $('#document_charges').val(s_charge_less);
            }else{
                let cal_service = parseFloat((p_amount / 100) * s_charge_greater) || 0;
                $('#document_charges').val(cal_service);
            }

        // run interest calculation when change the amount field
        $('#date, #date-period').on('keyup, change',function(e){
                e.preventDefault();
                calculateFinalDate();
                interestCalculations();
        })

        // Function to calculate and display the final date
        function calculateFinalDate() {
            let receiptDate = new Date("@foreach ($receiptData as $receipt){{ $receipt['Pawn_Date'] }}@endforeach");
            let today_str = $('#date').val();
            let today_format = new Date(today_str);

            // Calculate the time difference in milliseconds
            let timeDiffMilliseconds = today_format - receiptDate;
            // Convert milliseconds to days
            let date_range_days = Math.floor(timeDiffMilliseconds / (1000 * 60 * 60 * 24)) + 1;
            // Display the date range
            let DateRangeDisplay = document.getElementById("date-period");
            DateRangeDisplay.textContent = date_range_days;
        }

        function interestCalculations(){
            let receiptDate = new Date(
            "@foreach ($receiptData as $receipt){{ $receipt['Pawn_Date'] }}@endforeach");
            let today_str = $('#date').val();
            let today_format = new Date(today_str);

            // Calculate the time difference in milliseconds
            let timeDiffMilliseconds = today_format - receiptDate;
            // Convert milliseconds to days
            let date_range_days = Math.floor(timeDiffMilliseconds / (1000 * 60 * 60 * 24)) + 1;


            // getting period details
            let receipt_name='';
            let period1 = 0;
            let period2 = 0;
            let period3 = 0;
            let rate1 = 0;
            let rate2 = 0;
            let rate3 = 0;
            let valid_period  = 0;
            let s_char_less = 0;
            let s_char_grea = 0;

            @foreach ($receiptTypeData as $receiptType)
                receipt_name = '{{ $receiptType['receiptname'] }}';
                period1 += {{ $receiptType['period1'] }};
                period2 += {{ $receiptType['period2'] }};
                period3 += {{ $receiptType['period3'] }};
                rate1 += {{ $receiptType['rate1'] }};
                rate2 += {{ $receiptType['rate2'] }};
                rate3 += {{ $receiptType['rate3'] }};
                valid_period += {{ $receiptType['validPeriod'] }};
                s_char_less += {{ $receiptType['s_charge_less'] }};
                s_char_grea += {{ $receiptType['s_charge_greater'] }};
            @endforeach;

            // Calculate the interest
            let amount = parseFloat( {{  $receiptData[0]['Pawn_Amount'] }} ) || 0;
            let months = Math.ceil(date_range_days / 30);
            let panelty_dif = date_range_days-valid_period;
            let total_int = 0;

            if(receipt_name === "D" ){
                let interest = (((amount / 100) * rate2 ) * months).toFixed(2);
                $('#interest').val(interest);

            }else{

                if(date_range_days > valid_period){
                    alert(date_range_days > valid_period);
                    let interest_set = parseFloat((((amount / 100) * rate2 * months)).toFixed(2)) || 0;
                    let panelty_rate = 0.5; // The penalty rate (0.5 for 50%)
                    let panelty_months = Math.ceil(panelty_dif / 30); // Calculate the number of penalty months
                    let panelty_interest = panelty_rate * panelty_months;
                    let panelty_charge = parseFloat((((amount / 100) * panelty_interest )).toFixed(2)) || 0;
                    let interest = interest_set + panelty_charge;
                    console.log(interest_set, panelty_charge);
                    $('#interest').val(interest);
                }else{

                let interest = 0;

                if (date_range_days <= period1) {
                interest = ((amount / 100) * rate1);
                } else if (date_range_days <= period2) {
                interest = ((amount / 100) * rate2);
                } else {
                let full_months = Math.floor(date_range_days / 30); // Count full 30-day months
                let remaining_days = date_range_days % 30; // Days left after full months

                // Interest for full months
                interest = ((amount / 100) * rate3 * full_months);

                // Check remaining days and apply appropriate rate
                if (remaining_days > 0) {
                    if (remaining_days <= period1) {
                        interest += ((amount / 100) * rate1);
                    } else if (remaining_days <= period2) {
                        interest += ((amount / 100) * rate2);
                    } else {
                        interest += ((amount / 100) * rate3);
                    }
                }
                }

                $('#interest').val(interest.toFixed(2));


                }

            }

            // Calling the total payment function
            redeemTotalCalculation();
        }


function redeemTotalCalculation() {
    let date_range_days = parseFloat($('#date_range_days').val()) || 0;
    let amount = parseFloat('{{ $receiptData[0]['Pawn_Amount'] }}') || 0;
  
    let totalvalueinterest = parseFloat('{{ $receiptData[0]['Total_Amount'] }}') || 0;
    let discount = parseFloat($('#redeem_discount').val()) || 0;
    let interest_to_pay = parseFloat($('#interest').val()) || 0;
    let document_charges = parseFloat($('#document_charges').val()) || 0;
    let stampduty = parseFloat($('#stampduty').val()) || 0;
    let total_pay;

    if (discount > 0) {
        total_pay = (amount + interest_to_pay + document_charges + stampduty - discount).toFixed(2);
    } else {
        total_pay = (amount + interest_to_pay + document_charges + stampduty).toFixed(2);
        totalvalue = (totalvalueinterest - (amount + interest_to_pay + stampduty)).toFixed(2);
    }
    
    let receiptTypeData = @json($receiptTypeData); // Convert PHP array to JavaScript
    let totalvalueinterestTotal = parseFloat('{{ $receiptData[0]['Total_Amount'] }}') || 0;
    let interestRatetwo;

    if (totalvalueinterestTotal >= 100000) {
    interestRatetwo = 1.68;
    } else if (totalvalueinterestTotal >= 50000 && totalvalueinterestTotal <= 99999) {
        interestRatetwo = 2;
    } else {
        interestRatetwo = 2.5;
    }

      let months_interest;
      
 
    months_interest = totalvalueinterest/100 * interestRatetwo;

    let Valid_Period = parseFloat('{{ $receiptData[0]['Valid_Period'] }}') || 0;  

let Interest1 = (Valid_Period >= 1) ? totalvalue : null;
let Interest2 = (Valid_Period >= 2) ? totalvalue - months_interest: null;
let Interest3 = (Valid_Period >= 3) ? totalvalue - months_interest * 2 : null;
let Interest4 = (Valid_Period >= 4) ? totalvalue - months_interest * 3 : null;
let Interest5 = (Valid_Period >= 5) ? totalvalue - months_interest * 4 : null;
let Interest6 = (Valid_Period >= 6) ? totalvalue - months_interest * 5 : null;
let Interest7 = (Valid_Period >= 7) ? totalvalue - months_interest * 6 : null;
let Interest8 = (Valid_Period >= 8) ? totalvalue - months_interest * 7 : null;
let Interest9 = (Valid_Period >= 9) ? totalvalue - months_interest * 8 : null;
let Interest10 = (Valid_Period >= 10) ? totalvalue - months_interest * 9 : null;
let Interest11 = (Valid_Period >= 11) ? totalvalue - months_interest * 10 : null;
let Interest12 = (Valid_Period >= 12) ? totalvalue - months_interest * 11 : null;

// Setting values for total payments
$('#redeem_total').val(total_pay);
$('#redeem_ammount').val(total_pay);
$('#ammount').val(totalvalueinterest);

// Function to set values and hide null fields
function setInterestField(id, value) {
    let field = $('#' + id);
    field.val(value);
    if (value === null) {
        field.closest('td').hide(); // Hides the entire table cell
    } else {
        field.closest('td').show();
    }
}

// Assigning values and hiding null fields
setInterestField('Interest1', Interest1);
setInterestField('Interest2', Interest2);
setInterestField('Interest3', Interest3);
setInterestField('Interest4', Interest4);
setInterestField('Interest5', Interest5);
setInterestField('Interest6', Interest6);
setInterestField('Interest7', Interest7);
setInterestField('Interest8', Interest8);
setInterestField('Interest9', Interest9);
setInterestField('Interest10', Interest10);
setInterestField('Interest11', Interest11);
setInterestField('Interest12', Interest12);


}
$('#redeem_discount').on('keyup', function(e) {
    e.preventDefault();
    redeemTotalCalculation();
});


});

</script>