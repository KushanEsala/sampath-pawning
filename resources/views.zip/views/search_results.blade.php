@if($recipts->count() > 0)
<h2 class="text-center">Pawning Receipts</h2>
<div class="text-center mb-3">
    <a href="{{ route('home') }}" class="btn btn-secondary">Back</a>
</div>
@else
<p class="text-center text-danger">No results found.</p>
@endif

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pawning Receipts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- DataTables & Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <style>
        table.dataTable th, table.dataTable td {
            white-space: nowrap;
        }
    </style>
</head>
<body class="p-3">

    <!-- Date Filter Form -->
    <form action="" method="get" class="mb-4 d-flex gap-3 align-items-end">
        <div>
            <label for="from_date" class="form-label">From Date:</label>
            <input type="date" name="from_date" id="from_date" class="form-control">
        </div>

        <div>
            <label for="to_date" class="form-label">To Date:</label>
            <input type="date" name="to_date" id="to_date" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <!-- Receipt Table -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered display nowrap" id="receiptTable">
            <thead class="table-dark text-center">
                <tr>
                    <th>NIC</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Type</th>
                    <th>Tictet  #</th>
                    <th>Date</th>
                    <th>Pawn Wt.</th>
                    <th>Total Wt.</th>
                    <th>Amount</th>
                    <th>OC</th>
                    <th>BC</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($recipts as $receipts)
                <tr>
                    <td>{{ $receipts->Customer_NIC }}</td>
                    <td>{{ $receipts->Customer_Name }}</td>
                    <td>{{ $receipts->Customer_Address }}</td>
                    <td>{{ $receipts->Customer_Phone }}</td>
                    <td>{{ $receipts->Receipt_Type }}</td>
                    <td>{{ $receipts->Receipt_Number }}</td>
                    <td>{{ $receipts->Receipt_Date }}</td>
                    <td>{{ $receipts->Pawn_Weight }}</td>
                    <td>{{ $receipts->Total_Weight }}</td>
                    <td>{{ $receipts->Amount }}</td>
                    <td>{{ $receipts->OC }}</td>
                    <td>{{ $receipts->BC }}</td>
                </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr class="table-secondary text-center">
                    <td colspan="7" class="text-center fw-bold">Total:</td>
                    <td><strong>{{ $pawnWeight }}</strong></td>
                    <td><strong>{{ $totalWeight }}</strong></td>
                    <td><strong>{{ $totalAmount }}</strong></td>
                    <td colspan="2"></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Print Button -->
    <div class="mt-3 text-center">
        <button onclick="printTablefun()" class="btn btn-success">Print</button>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables and Export Scripts -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <script>
        $(document).ready(function () {
            $('#receiptTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'pdfHtml5',
                    'print'
                ],
                scrollX: true,
                pageLength: 1000
            });

            // Set today's date to 'to_date' input
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('to_date').value = today;
        });

        function printTablefun() {
            let printContent = document.getElementById("receiptTable").outerHTML;
            let newWin = window.open("");
            newWin.document.write("<html><head><title>Print</title>");
            newWin.document.write("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'>");
            newWin.document.write("</head><body>");
            newWin.document.write(printContent);
            newWin.document.write("</body></html>");
            newWin.print();
            newWin.close();
        }
    </script>
</body>
</html>