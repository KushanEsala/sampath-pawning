<div class="col ">
    <div class="row">
        <div class="col">
            <input type="hidden" id="operator" name="operator" value="{{ Auth::user()->name }}" required>

            @foreach ($receiptData as $receipt)
            <input type="hidden" id="r_number" name="r_number" value="{{ $receipt['Receipt_Number'] }}" required>
            <input type="hidden" id="i_number" name="i_number" value="{{ $receipt['Invoice_Number'] }}">
            <input type="hidden" id="t_number" name="t_number" value="{{ $receipt['Ticket_Number'] }}">

            <input type="hidden" id="sum_total_weight" name="sum_total_weight" value="{{ $receipt['Total_Weight'] }}">
            <input type="hidden" id="sum_pawn_weight" name="sum_pawn_weight" value="{{ $receipt['Pawn_Weight'] }}">
            @endforeach


            <label for="receipt_type">Receipt Type :
                <input class="form-control"  type="text" placeholder="Receipt type"
                    name="receipt_type"
                    @foreach ($receiptData as $receipt)
                    value="{{$receipt['Receipt_Type']}}"
                    @endforeach
                    id="receipt_type" readonly/>
            </label>
        </div>
        <div class="col">
                <label for="date">Date :
                    <input class="form-control" type="date"
                    id="date"
                    @foreach ($receiptData as $receipt)
                    value="{{ $receipt['Pawn_Date'] }}"
                    @endforeach
                    name="redeem_date" required>
                </label>
        </div>
        <div class="col">
            <label for="redeem_no">Redeem Number :
                <input class="form-control" type="text" placeholder="Redeem Number:"
                value="{{ $maxRedeem+1 }}"
                id="redeem_no" name="redeem_no" required>
            </label>
        </div>
        <div class="col">
            @if($pawnType == "Pawn")
            <label for="pawn_receipt_type"><span class="text-success">Pawn Receipt Type :</span>
                <input class="form-control text-success" type="text" placeholder="Pawn Receipt Type:"
                value="{{ $pawnType }}"
                id="pawn_receipt_type" name="pawn_receipt_type" required readonly>
            </label>
            @elseif($pawnType == "Opening_Pawn")
            <label for="pawn_receipt_type"><span class="text-primary">Pawn Receipt Type :</span>
                <input class="form-control text-primary" type="text" placeholder="Pawn Receipt Type:"
                value="{{ $pawnType }}"
                id="pawn_receipt_type" name="pawn_receipt_type" required readonly>
            </label>

            @endif
        </div>
    </div>
</div>
<h5 class="mt-3 mb-2">Receipt Info</h5>
<table class="table table-bordered text-center" id="dynamicAdded">
    <thead class="thead-light">
        <tr>
            <th>Final Date</th>
            <th>Receipt Date Time</th>
            <th>Period (Days)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <p id="date-final"></p>
            </td>
            <td>
                <p>
                @foreach ($receiptData as $receipt)
                   {{ $receipt['Pawn_Date'] }}
                @endforeach
                </p>
            </td>
            <td>
                <p id="date-period"></p>
            </td>
        </tr>
    </tbody>
</table>
<table class="table table-bordered text-center" id="dynamicAdded">
    <thead class="thead-light">
        <tr>
            <th>Paid Advance Payment</th>
            <th>Paid Interest Payment</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <p>
                @foreach ($receiptData as $receipt)
                @foreach ($receiptData as $receipt)
                {{ ($receipt['Amount'] ?? 0) - ($receipt['Pawn_Amount'] ?? 0) }}
            @endforeach
            
                @endforeach
                </p>
            </td>
            <td>
                <p>
                    @foreach ($receiptData as $receipt)
                       {{ $receipt['interest_Paid'] }}
                    @endforeach
                    </p>
            </td>
        </tr>
    </tbody>
</table>
<br>
<h5 class="mt-3 mb-2">Customer Info</h5>
<table class="table table-bordered text-center" id="dynamicAdded">
    <thead class="thead-light">
        <tr>
            <th>Customer NIC </th>
            <th>Customer Address </th>
            <th>Customer Contact Number</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            @foreach ($customerData as $customer )
            <td><h5>{{ $customer['NIC'] }}</h5></td>
            <td><h5>{{ $customer['Address_1'] }}</h5></td>
            <td><h5>{{ $customer['Contact_1'] }}</h5></td>
            @endforeach
        </tr>
    </tbody>
    <thead class="thead-light">
        <tr>
                <th colspan="2" >Customer Name </th>
                <th>Customer ID</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            @foreach ($customerData as $customer )
            <td colspan="2"> <h5>{{ $customer['First_name'] }} {{ $customer['Middle_name'] }} {{ $customer['Last_name'] }}</h5></td>
         
            <td ><h5>{{ $customer['Code'] }}</h5></td>
            @endforeach
        </tr>
    </tbody>
</table>

<input type="hidden"  class="form-control text-center" value="{{ $customer['First_name'] }} {{ $customer['Last_name'] }}" name="Customer_Name" id="Customer_Name">
<input type="hidden" class="form-control text-center" value="{{ $customer['NIC'] }}" id="Customer_NIC" name="Customer_NIC">

<br>
<h5 class="mt-3 mb-2">Article Details</h5>
<table class="table table-bordered text-center" >
    <thead class="thead-light">
        <tr>
            <th>Pawn Weight </th>
            <th>Total Weight</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            @foreach ($receiptData as $receipt )
            <td><h5> {{ number_format($receipt['Pawn_Weight'], 3) }} g <br></h5></td>
            <td><h5> {{ number_format($receipt['Total_Weight'], 3) }} g</h5></td>
            @endforeach
        </tr>
    </tbody>
</table>

<br>
<div class="row" style="align-content: center;">
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12">
                <button class="btn btn-outline-info form-control" type="button"
                data-bs-toggle="modal" data-bs-target="#viewArticleDetailsModel">
                <i class="far fa-eye me-1"></i>
                    View Article Details
                </button>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="col-md-12">
            <button class="btn btn-outline-info form-control" type="button"
            data-bs-toggle="modal" data-bs-target="#viewPaymentHistoryModel">
            <i class="far fa-eye me-1"></i>
                Payment History
            </button>
        </div>
    </div>
</div>
<br>
<h5 class="mt-3 mb-2">Redeem Details</h5>
<table class="table table-bordered text-center" id="dynamicAdded">
    <tbody class="thead-light">
        <tr>
            <th>Original Pawn Amount</th>
            <td>
                @foreach ($receiptData as $receipt)
                <p>
                    <input class="form-control text-center"  type="text" placeholder="Original Pawn Amount"
                        value="" id="total" readonly/>

                    <input type="hidden"
                    name="original_pawn_amount"
                    value="{{ $receipt['Pawn_Amount'] + $receipt['interest_Paid'] }}"
                    id="original_pawn_amount" readonly/>

                    <input type="hidden" id="BalanceInterest" name="BalanceInterest" text=''>
                </p>
                @endforeach
            </td>
        </tr>
        <tr>
            <th>Paid Interest</th>
            <td>
                <p>
                    <input class="form-control text-center" id="interest" type="text" placeholder="Paid Interest"
                    name="paid_interest" value="" readonly/>
                </p>
            </td>
        </tr>
        <tr>
            <th>Stampduty</th>
            <td>
                <p>
                    <input class="form-control text-center" id="stampduty" type="text" placeholder="Stampduty"
                    name="stampduty" value="" readonly/>
                </p>
            </td>
        </tr>
        <tr>
            <th>Service Charges</th>
            <td>
                <p>
                    <input class="form-control text-center" id="document_charges" type="text" placeholder="Document Charges"
                    name="document_charges" value="" readonly/>
                </p>
            </td>
        </tr>
    </tbody>
</table>


<br>


{{-- Functions for date and time  calculation --}}
<script>
    $(document).ready(function () {

        // form default date set for today
        document.getElementById('date').valueAsDate = new Date();

        calculateFinalDate();
        interestCalculations();

        //getting document charges
        let doc_chargers = 0 ;
        let stampduty = 0 ;
        let s_charge_less = 0;
        let s_charge_greater= 0;

            @foreach ($receiptTypeData as $receiptType)
                doc_chargers = {{ $receiptType['documentCharges'] }};
                stampduty = {{ $receiptType['stampduty'] }};
                s_charge_less = parseFloat({{ $receiptType['s_charge_less'] }}) || 0;
                s_charge_greater = parseFloat({{ $receiptType['s_charge_greater'] }}) || 0;
            @endforeach;

            // $('#document_charges').val(doc_chargers);

            let p_amount = parseFloat( {{  $receiptData[0]['Pawn_Amount'] }} ) || 0;
            if(p_amount < 25000){
                $('#document_charges').val(s_charge_less);
            }else{
                let cal_service = parseFloat((p_amount / 100) * s_charge_greater) || 0;
                $('#document_charges').val(cal_service);
            }

        // run interest calculation when change the amount field
        $('#date, #date-period').on('keyup, change',function(e){
                e.preventDefault();
                calculateFinalDate();
                interestCalculations();
        })

        // Function to calculate and display the final date
        function calculateFinalDate() {
            let receiptDate = new Date("@foreach ($receiptData as $receipt){{ $receipt['Pawn_Date'] }}@endforeach");
            let today_str = $('#date').val();
            let today_format = new Date(today_str);

            // Calculate the time difference in milliseconds
            let timeDiffMilliseconds = today_format - receiptDate;
            // Convert milliseconds to days
            let date_range_days = Math.floor(timeDiffMilliseconds / (1000 * 60 * 60 * 24)) + 1;
            // Display the date range
            let DateRangeDisplay = document.getElementById("date-period");
            DateRangeDisplay.textContent = date_range_days;
        }

        function interestCalculations(){
            let receiptDate = new Date("@foreach ($receiptData as $receipt){{ $receipt['Pawn_Date'] }}@endforeach");
            let today_str = $('#date').val();
            let today_format = new Date(today_str);

            // Calculate the time difference in milliseconds
            let timeDiffMilliseconds = today_format - receiptDate;
            // Convert milliseconds to days
            let date_range_days = Math.floor(timeDiffMilliseconds / (1000 * 60 * 60 * 24)) + 1;


            // getting period details
            let receipt_name='';
            let period1 = 0;
            let period2 = 0;
            let period3 = 0;
            let rate1 = 0;
            let rate2 = 0;
            let rate3 = 0;
            let valid_period  = 0;
            let s_char_less = 0;
            let s_char_grea = 0;

            @foreach ($receiptTypeData as $receiptType)
                receipt_name = '{{ $receiptType['receiptname'] }}';
                period1 += {{ $receiptType['period1'] }};
                period2 += {{ $receiptType['period2'] }};
                period3 += {{ $receiptType['period3'] }};
                rate1 += {{ $receiptType['rate1'] }};
                rate2 += {{ $receiptType['rate2'] }};
                rate3 += {{ $receiptType['rate3'] }};
                valid_period += {{ $receiptType['validPeriod'] }};
                s_char_less += {{ $receiptType['s_charge_less'] }};
                s_char_grea += {{ $receiptType['s_charge_greater'] }};
            @endforeach;


            // Calculate the interest
            let amount = parseFloat( {{  $receiptData[0]['Pawn_Amount'] }} ) || 0;
            let paid_interest = parseFloat( {{  $receiptData[0]['interest_Paid'] }} ) || 0;
            let months = Math.ceil(date_range_days / 30);
            let panelty_dif = date_range_days-valid_period;
            let total_int = 0;''

            if(receipt_name === "D" ){
                let interest = (((amount / 100) * rate2 ) * months).toFixed(2);
                $('#interest').val(interest);

            }else{

                if (date_range_days > valid_period && receipt_name === "D") {
                    alert(date_range_days > valid_period);
                    let interest_set = parseFloat((((amount / 100) * rate2 * months)).toFixed(2)) || 0;
                    let panelty_rate = 0.5; // The penalty rate (0.5 for 50%)
                    let panelty_months = Math.ceil(panelty_dif / 30); // Calculate the number of penalty months
                    let panelty_interest = panelty_rate * panelty_months;
                    let panelty_charge = parseFloat((((amount / 100) * panelty_interest )).toFixed(2)) || 0;
                    let interest = interest_set + panelty_charge - paid_interest;
                    console.log(interest_set, panelty_charge);
                    $('#interest').val(interest);
                }else{

                    let interest = 0;

                if (date_range_days <= period1) {
                    interest = ((amount / 100) * rate1);
                } else if (date_range_days <= period2) {
                    interest = ((amount / 100) * rate2);
                } else {
                    let full_months = Math.floor(date_range_days / 30); // Count full 30-day months
                    let remaining_days = date_range_days % 30; // Days left after full months

                    // Interest for full months
                    interest = ((amount / 100) * rate3 * full_months);

                    // Check remaining days and apply appropriate rate
                    if (remaining_days > 0) {
                        if (remaining_days <= period1) {
                            interest += ((amount / 100) * rate1);
                        } else if (remaining_days <= period2) {
                            interest += ((amount / 100) * rate2);
                        } else {
                            interest += ((amount / 100) * rate3);
                        }
                    }
                }

                     $('#interest').val(interest.toFixed(2));

                    
                }

            }
            redeemTotalCalculation();
             
        }


        // Calling the total payment function
        redeemTotalCalculation();
        // Calculate the total payment
        function redeemTotalCalculation() {
            // Parse values from inputs
            let amount = parseFloat( {{  $receiptData[0]['Pawn_Amount'] }} ) || 0;
            let paid_interest = parseFloat( {{  $receiptData[0]['interest_Paid'] }} ) || 0;
            let Bal_int = parseFloat( {{  $receiptData[0]['BalanceInterest'] }} ) || 0;
            let discount = parseFloat($('#redeem_discount').val()) || 0;
            let advance_payment = parseFloat($('#advance_payment').val()) || 0;
            let interest_Paid = parseFloat($('#interest_Paid').val()) || 0;
            let interest_to_pay = parseFloat($('#interest').val()) || 0;
            let document_charges = parseFloat($('#document_charges').val()) || 0;
            let stamp_duty = parseFloat($('#stampduty').val()) || 0;

            // Calculate total payment
            let totalPay = interest_to_pay + document_charges + stamp_duty + amount ;
            let interestpay = interest_to_pay + document_charges + stamp_duty ;

            // Ensure totalPay is not negative
            if (totalPay < 0) {
                totalPay = 0;
            }

     // Update input fields
        $('#redeem_total').val(totalPay.toFixed(2));
        $('#total').val(amount.toFixed(2));
        $('#BalanceInterest').val((interest_to_pay - interest_Paid).toFixed(2));

        // Calculate advance payment and ensure it's not negative
        let advancePayment = interest_Paid - interestpay;
        $('#advance_payment').val(advancePayment > 0 ? advancePayment.toFixed(2) : '0.00');

        // Calculate pawning payment and ensure it's not negative
        let pawningPayment = amount + interestpay - interest_Paid;
        $('#pawning_payment').val(pawningPayment > 0 ? pawningPayment.toFixed(2) : '0.00');
        
        // Calculate payable total
        $('#payable_total').val((interest_Paid - discount).toFixed(2));

        // Ensure PayTotalAmount is not negative
        let payTotalAmount = totalPay - advancePayment - document_charges - (pawningPayment > 0 ? pawningPayment : 0);
        $('#PayTotalAmount').val(payTotalAmount > 0 ? payTotalAmount.toFixed(2) : '0.00');
        }

        // Event listener to trigger the calculation
        $(document).on('input', '#redeem_discount,#total,#BalanceInterest,#PayTotalAmount  #advance_payment,#interest_Paid, #interest, #document_charges, #stampduty,#pawning_payment', function () {
            redeemTotalCalculation();
        });


        // run total pay calculation when change the discount field
        $('#redeem_discount').on('keyup',function(e){
            e.preventDefault();
            redeemTotalCalculation();
        })


    });

</script>