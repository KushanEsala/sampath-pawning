<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt Sample</title>
    <link rel="stylesheet" href="style.css">
    <style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

.container {
    /* display: block; */
    /* width: 100%; */
    background: #f7f7f7;
    max-width: 280px;
    padding: 10px;
    /* margin: 50px auto 0; */
    /* box-shadow: 0 3px 10px rgb(0 0 0 / 0.2); */
}


.receipt_header {
    padding-bottom: 40px;
    border-bottom: 1px dashed #000;
    text-align: center;
}

.receipt_header h1 {
    font-size: 15px;
    margin-bottom: 5px;
    text-transform: uppercase;
}

.receipt_header h1 span {
    display: block;
    font-size: 25px;
}

.receipt_header h2 {
    font-size: 14px;
    color: #727070;
    font-weight: 300;
}

.receipt_header h2 span {
    display: block;
}

.receipt_body {
    margin-top: 25px;
}

table {
    width: 100%;
}

thead, tfoot {
    position: relative;
}

thead th:not(:last-child) {
    text-align: left;
}

thead th:last-child {
    text-align: right;
}

thead::after {
    content: '';
    width: 100%;
    border-bottom: 1px dashed #000;
    display: block;
    position: absolute;
}


tbody td:not(:last-child), tfoot td:not(:last-child) {
    text-align: left;
}

tbody td:last-child, tfoot td:last-child{
    text-align: right;
}

tbody tr:first-child td {
    padding-top: 15px;
}

tbody tr:last-child td {
    padding-bottom: 15px;
}

tfoot tr:first-child td {
    padding-top: 15px;
}

tfoot::before {
    content: '';
    width: 100%;
    border-top: 1px dashed #000;
    display: block;
    position: absolute;
}

tfoot tr:first-child td:first-child, tfoot tr:first-child td:last-child {
    font-weight: bold;
    font-size: 20px;
}

.date_recei {
    display: flex;
    justify-content: left;
    column-gap: px;
}

.date_time_con {
    display: flex;
    justify-content: center;
    column-gap: 15px;
}

.items {
    margin-top: 25px;
}

h3 {
    border-top: 1px dashed #000;
    padding-top: 10px;
    margin-top: 25px;
    text-align: center;
    text-transform: uppercase;
}

    </style>
</head>
<body>
    
<div class="container">
    @foreach ($companyData as $comData)
    <div class="receipt_header">
    <h3><span>{{ $comData->name}}</span></h3>
    <h6 style="font-size: 12px">Address : {{ $comData->address}}</h6>
    <h6><span>Phone : {{ $comData->co_number}} | {{ $comData->fax_number}}</span></h6>
    <h5>Email : <a href="mailto:{{ $comData->email}}">{{ $comData->email}}</a></span></h5>
    </div>
    @endforeach
    <div class="receipt_body">
        <div class="date_time_con" style="text-align: justify ;">
            @foreach($redeemdata as $sumData)
                <div class="date" style="font-size: 12px;text-align:center;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Redemption No:&nbsp;&nbsp;&nbsp;&nbsp; {{ $sumData['Receipt_Number'] }}</div>
                <div class="date" style="font-size: 12px;text-align: right;">Redemption Date: {{ $sumData['Redeem_Date'] }}</div>
            @endforeach
        </div>        
<br>
        <div class="date_time_con">
            @foreach($pawnSumData as $sumData)
            <div class="date" style="font-size: 12px">Pawning No :&nbsp;&nbsp;&nbsp;&nbsp;{{$sumData['Invoice_Number']}}</div>
            <div class="time" style="font-size: 12px">Pawning Date :&nbsp;{{$sumData['Receipt_Date']}}</div>
            @endforeach
        </div>
      <br>   
    <div class="date_recei">
        @foreach($pawnSumData as $sumData)
        <div class="date" style="font-size: 12px">Name : {{$sumData['Customer_Name']}}</div>
        <div class="date" style="font-size: 12px">Address :&nbsp;{{$sumData['Customer_Address']}}<</div>
        <div class="date" style="font-size: 12px">NIC : {{$sumData['Customer_NIC']}}</div>
        <div class="time" style="font-size: 12px">Phone : {{$sumData['Customer_Phone']}}</div>
        @endforeach
    </div>
  
        <div class="items">
            <table>
        
                <thead>
                    <th class="w-40" style="text-align: left;font-size: 15px">Articles</th>
                    <th class="w-30" style="text-align: right;font-size: 15px">Weight</th>
                    <th class="w-50" style="text-align: right;font-size: 15px">&nbsp;&nbsp;&nbsp;&nbsp;QTY</th>
                </thead>
        
                <tbody>
                    @foreach($pawnDetailsData as $DetailsData)
                    <tr align="center" style="text-align: center;">
                        <td style="text-align: left; font-size: 12px">{{$DetailsData['Articles']}}</td>
                        <td style="text-align: right;font-size: 12px">{{$DetailsData['Weight']}}</td>
                        <td style="text-align: right;font-size: 12px">{{$DetailsData['QTY']}}</td>
                        @endforeach
                        {{-- @foreach($redeemdata as $sumData)
                        <td style="text-align: right;font-size: 12px">{{$sumData['Payable_Pawn_Amount']}}</td>
                        @endforeach --}}
                    </tr>
                </tbody>

                <tfoot>

                    <tr>
                        <td colspan="2" align="left"><Strong style="font-size: 14px">Pawning Advance A/C</Strong></td>
                        <td>      
                            @foreach($redeemdata as $sumData)
                            <p><strong style="font-size: 13px">{{ number_format($sumData['Payable_Pawn_Amount'], 2, '.', ',') }}</strong></p>
                            @endforeach
                        </td>
                    </tr>
                    <tr>
                        <td> <strong  style="font-size: 13px">Interest Received A/C</strong></td>
                        <td></td>
                        <td>      
                            @foreach($redeemdata as $sumData)
                            <p><strong style="font-size: 11px">{{ number_format($sumData['Paid_Interest'], 2, '.', ',') }}</strong></p>
                            @endforeach
                        </td>
                    </tr>

                    <tr>
                        <td> <strong  style="font-size: 13px">Stamp Fee</strong></td>
                        <td></td>
                        <td>      
                            @foreach($redeemdata as $sumData)
                            <p><strong style="font-size: 11px">{{ number_format($sumData['Stamp_Fee'], 2, '.', ',') }}</strong></p>
                            @endforeach
                        </td>
                    </tr>
                    


                    <tr>
                        <td colspan="2" align="left" > <strong style="font-size: 14px">Payable Pawn Amount</strong></td>
                        <td>      
                            @foreach($redeemdata as $sumData)
                            <p style="font-size: 14px"><strong>{{ number_format($sumData['Payable_Total'] + $sumData['Discount'], 2, '.', ',') }}</strong></p>
                            @endforeach
                        </td>
                    </tr>

                    <tr>
                        <td>Discount</td>
                        <td></td>
                        <td> 
                            @foreach($redeemdata as $sumData)
                            <p style="font-size: 11px">{{$sumData['Discount']}}</p>
                            @endforeach
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2" align="left"><Strong>Total Amount</Strong></td>
                        <td><Strong> @foreach($redeemdata as $sumData)
                            <p>{{$sumData['Payable_Total']}}</p>
                            @endforeach
                            <Strong></td>
                    </tr>
                </tfoot>

            </table>
        </div>

    </div>


    <h3>Thank You!</h3>

</div>

</body>
</html>