@extends('layouts.topnavbar')
@extends('layouts.sidebar')
@section('content')
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
        <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
        <title>Late Letters</title>
    </head>
    <body>
        <div class="main-wrapper">
            <div class="page-wrapper">
                <div class="content container-fluid">
                    <div class="card shadow ">
                        <div class="col-md-9">
                            <h4 class="card-title m-3">Late Letters</h4>
                        </div>
                        <hr size="6" style="color: blue">
                        {{-- alert section --}}
                        <div class="row">
                            <div class="col-sm-12">
                                @if (session('delete'))
                                <div class="alert alert-danger text-center" role="alert">
                                    {{session('delete')}} &#10004;
                                </div>
                                @endif

                                @if (session('added'))
                                <div class="alert alert-success text-center" role="alert">
                                    {{session('added')}} &#10004;
                                </div>
                                @endif
                                @if ($errors->any())
                                <div class="alert alert-danger" role="alert">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col">
                                {{-- Receipt Table --}}
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <div class="table-data">
                                            <div class="card shadow p-3 mb-3 bg-body-tertiary rounded " >

                                                <a href="javascript:void(0);" class="btn btn-primary mb-1" onclick="printLateRedeemTable()">Print List <i class="fa fa-print"></i></a>
                                              <br>
                                              
                                              <br>
                                                
                                              <form action="{{ route('late_redeem_list') }}" method="POST">
                                                @csrf
                                                <div class="form-group">
                                                    <label for="receipt_type">Receipt Type:</label>
                                                    <select class="form-select" id="receipt_type" name="receipt_type" required>
                                                        <option value="">Please Select</option>
                                                        @foreach($receiptType as $receiptData)
                                                        <option value="{{ $receiptData->receiptname }}">{{ $receiptData->receiptname }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <button type="submit" class="btn btn-primary mb-1">Submit</button>
                                            </form>
                                            
                                           <br>
                                           <br>
                                                <div class="table-responsive" >
                                                    <table class="table table-center table-bordered  table-hover" id="LateRedeemtablecus1" >
                                                        <tr class="styled-table text-center">
                                                            <th>NIC</th>
                                                            <th>Name</th>
                                                            <th>Address</th>
                                                            <th>Phone</th>
                                                            <th>Receipt No</th>
                                                            <th>Receipt Type</th>
                                                            <th>Date</th>
                                                            <th>Final Date</th>
                                                            <th>Amount</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <tbody>
                                                            @php
                                                                $sum_total = 0;
                                                                $company_name= "";
                                                                $company_address= "";
                                                                $company_number= "";
                                                            @endphp
                                                            @foreach ($companyData as $company)
                                                                @php
                                                                    $company_name = $company->name;
                                                                    $company_address = $company->address;
                                                                    $company_number = $company->co_number;
                                                                @endphp
                                                            @endforeach
                                                            @foreach ( $recipts as $key=>$receipts)
                                                            <tr>
                                                                <td>{{$receipts->Customer_NIC }}</td>
                                                                <td>{{$receipts->Customer_Name}}</td>
                                                                <td>{{$receipts->Customer_Address }}</td>
                                                                <td>{{$receipts->Customer_Phone }}</td>
                                                                <td>{{$receipts->Receipt_Number }}</td>
                                                                <td>{{$receipts->Receipt_Type }}</td>
                                                                <td>{{$receipts->Receipt_Date}}</td>
                                                                <td>{{$receipts->Final_date}}</td>
                                                                <td class="text-end">{{$receipts->Amount}}</td>

                                                                @if ($receipts->is_letter_2 === 1)
                                                                    <td>
                                                                        <a href="" id="show_letter"
                                                                            class="btn btn-sm btn-danger bg-danger-light text-danger me-2"
                                                                            data-bs-toggle="modal" data-bs-target="#letter3Model{{$receipts->Receipt_Number}}"
                                                                            data-id="{{$receipts->id}}"
                                                                            data-Customer_NIC="{{$receipts->Customer_NIC}}"
                                                                            data-Customer_Name="{{$receipts->Customer_Name}}"
                                                                            data-Customer_Address="{{$receipts->Customer_Address}}"
                                                                            data-Customer_Phone="{{$receipts->Customer_Phone}}"
                                                                            data-Receipt_Number="{{$receipts->Receipt_Number}}"
                                                                            data-Receipt_Type="{{$receipts->Receipt_Type}}"
                                                                            data-Receipt_Date="{{$receipts->Receipt_Date}}"
                                                                            data-Amount="{{$receipts->Amount}}">
                                                                            <i class="far fa-edit me-1"></i> 3 rd Letter
                                                                        </a>
                                                                        {{-- ............Letter 3 model................................. --}}
                                                                        <div class="modal fade" id="letter3Model{{$receipts->Receipt_Number}}" tabindex="-1" role="dialog" aria-labelledby="letterModelLabel"
                                                                            aria-hidden="true">
                                                                            <div class="modal-dialog modal-lg">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h4 class="modal-title m-1" id="updateReceiptModelLabel"> Redeem Letter </h4>
                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="col-md-12">
                                                                                            <div class="card">
                                                                                                <div class="card-body">
                                                                                                    <div class="errMsgContainer2"></div>
                                                                                                    <form action="" method="post" id="updateReceipt">
                                                                                                        @csrf
                                                                                                        <h4 class="text-center">3rd Reminder Letter</h4>
                                                                                                        <div class="row">
                                                                                                            <div>
                                                                                                                <p>
                                                                                                                    [Your Name] <br>
                                                                                                                    [Your Address] <br>
                                                                                                                    [City, State, Zip Code] <br>
                                                                                                                    [Your Phone Number] <br>
                                                                                                                    [Today's Date] <br>
                                                                                                                    <br>
                                                                                                                    {{$receipts->Customer_Name}}<br>
                                                                                                                    {{$receipts->Customer_Address}} <br>
                                                                                                                    <br>
                                                                                                                    Dear {{$receipts->Customer_Name}}, <br>
                                                                                                                    <br>
                                                                                                                    We hope this letter finds you well. We are writing to remind you of the redemption of your pawn<br>
                                                                                                                    with us, which is now late. As per our records, your pawn, with the following details: <br>
                                                                                                                    <br>
                                                                                                                    <table>
                                                                                                                        <tr>
                                                                                                                            <td>Customer ID </td>
                                                                                                                            <td>: {{$receipts->Customer_NIC}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Name </td>
                                                                                                                            <td>: {{$receipts->Customer_Name}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Address </td>
                                                                                                                            <td>: {{$receipts->Customer_Address}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Phone Number </td>
                                                                                                                            <td>: {{$receipts->Customer_Phone}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Receipt Number </td>
                                                                                                                            <td>: {{$receipts->Receipt_Number}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Redemption Date </td>
                                                                                                                            <td>: {{$receipts->Receipt_Date}}</td>
                                                                                                                        </tr>
                                                                                                                        <tr>
                                                                                                                            <td>Redemption Amount </td>
                                                                                                                            <td>: {{$receipts->Amount}}</td>
                                                                                                                        </tr>
                                                                                                                    </table>

                                                                                                                    <br>
                                                                                                                    was due for redemption on {{$receipts->Receipt_Date}}. However, we understand that circumstances <br>
                                                                                                                    may have caused a delay in the redemption process. <br>
                                                                                                                    <br>
                                                                                                                    Please be advised that a late redemption fee may apply as per our terms and conditions. However, <br>
                                                                                                                    we are willing to work with you to resolve this matter promptly.Kindly get in touch with our <br>
                                                                                                                    customer service team at {{$company_number}} to discuss the next steps and to ensure the smooth <br>
                                                                                                                    completion of your pawn redemption.<br>
                                                                                                                    <br>
                                                                                                                    We value your patronage and are committed to providing you with the best possible service.Thank <br>
                                                                                                                    you for your attention to this matter, and we look forward to assisting you in resolving this issue. <br>
                                                                                                                    <br>
                                                                                                                    Sincerely,<br>
                                                                                                                    <br>
                                                                                                                    {{$company_name}}<br>
                                                                                                                    {{$company_address}}<br>
                                                                                                                    {{$company_number}}<br>
                                                                                                                </p>
                                                                                                            </div>

                                                                                                            <div class="text-center mt-4">
                                                                                                                <button type="button"
                                                                                                                    class="btn btn-success print_letter bg-success-light text-success me-2"
                                                                                                                    data-print_recept_no="{{$receipts->Receipt_Number}}"
                                                                                                                    data-letter_no="3">
                                                                                                                    <i class="fa fa-print" aria-hidden="true"></i>Print Letter</button>
                                                                                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                                                                                                    aria-label="Close">Close</button>
                                                                                                            </div>
                                                                                                    </form>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                @elseif($receipts->is_letter_1 === 1)
                                                                    <td>
                                                                        <a href="" id="show_letter"
                                                                            class="btn btn-sm btn-primary bg-primary-light text-primary me-2"
                                                                            data-bs-toggle="modal" data-bs-target="#letter2Model{{$receipts->Receipt_Number}}"
                                                                            data-id="{{$receipts->id}}"
                                                                            data-Customer_NIC="{{$receipts->Customer_NIC}}"
                                                                            data-Customer_Name="{{$receipts->Customer_Name}}"
                                                                            data-Customer_Address="{{$receipts->Customer_Address}}"
                                                                            data-Customer_Phone="{{$receipts->Customer_Phone}}"
                                                                            data-Receipt_Number="{{$receipts->Receipt_Number}}"
                                                                            data-Receipt_Type="{{$receipts->Receipt_Type}}"
                                                                            data-Receipt_Date="{{$receipts->Receipt_Date}}"
                                                                            data-Amount="{{$receipts->Amount}}">
                                                                            <i class="far fa-edit me-1"></i> 2 nd Letter
                                                                        </a>
                                                                        {{-- ............Letter 2 model................................. --}}
                                                                        <div class="modal fade" id="letter2Model{{$receipts->Receipt_Number}}" tabindex="-1" role="dialog" aria-labelledby="letterModelLabel"
                                                                            aria-hidden="true">
                                                                            <div class="modal-dialog modal-lg">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h4 class="modal-title m-1" id="updateReceiptModelLabel"> Redeem Letter </h4>
                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="col-md-12">
                                                                                            <div class="card">
                                                                                                <div class="card-body">
                                                                                                    <div class="errMsgContainer2"></div>
                                                                                                    <form action="" method="post" id="updateReceipt">
                                                                                                        @csrf
                                                                                                        <h4 class="text-center">2nd Reminder Letter</h4>
                                                                                                        <div class="row">
                                                                                                            <div>
                                                                                                                <p>
                                                                                                                    [Your Name] <br>
                                                                                                                    [Your Address] <br>
                                                                                                                    [City, State, Zip Code] <br>
                                                                                                                    [Your Phone Number] <br>
                                                                                                                    [Today's Date] <br>
                                                                                                                    <br>
                                                                                                                    {{$receipts->Customer_Name}}<br>
                                                                                                                    {{$receipts->Customer_Address}} <br>
                                                                                                                    <br>
                                                                                                                    Dear {{$receipts->Customer_Name}}, <br>
                                                                                                                    <br>
                                                                                                                    We hope this letter finds you well. We are writing to remind you of the redemption of your pawn<br>
                                                                                                                    with us, which is now late. As per our records, your pawn, with the following details: <br>
                                                                                                                    <br>
                                                                                                                    Customer ID: {{$receipts->Customer_NIC}} <br>
                                                                                                                    Name: {{$receipts->Customer_Name}} <br>
                                                                                                                    Address: {{$receipts->Customer_Address}} <br>
                                                                                                                    Phone Number: {{$receipts->Customer_Phone}} <br>
                                                                                                                    Receipt Number: {{$receipts->Receipt_Number}}<br>
                                                                                                                    Redemption Date: {{$receipts->Receipt_Date}} <br>
                                                                                                                    Redemption Amount: {{$receipts->Amount}} <br>
                                                                                                                    <br>
                                                                                                                    was due for redemption on {{$receipts->Receipt_Date}}. However, we understand that circumstances <br>
                                                                                                                    may have caused a delay in the redemption process. <br>
                                                                                                                    <br>
                                                                                                                    Please be advised that a late redemption fee may apply as per our terms and conditions. However, <br>
                                                                                                                    we are willing to work with you to resolve this matter promptly.Kindly get in touch with our <br>
                                                                                                                    customer service team at {{$company_number}} to discuss the next steps and to ensure the smooth <br>
                                                                                                                    completion of your pawn redemption.<br>
                                                                                                                    <br>
                                                                                                                    We value your patronage and are committed to providing you with the best possible service.Thank <br>
                                                                                                                    you for your attention to this matter, and we look forward to assisting you in resolving this issue. <br>
                                                                                                                    <br>
                                                                                                                    Sincerely,<br>
                                                                                                                    <br>
                                                                                                                    {{$company_name}}<br>
                                                                                                                    {{$company_address}}<br>
                                                                                                                    {{$company_number}}<br>

                                                                                                                    <input type="hidden" id="print_recept_no" name="print_recept_no" value="{{$receipts->Receipt_Number}}">
                                                                                                                </p>
                                                                                                            </div>

                                                                                                            <div class="text-center mt-4">
                                                                                                                <button type="button"
                                                                                                                    class="btn btn-success print_letter bg-success-light text-success me-2"
                                                                                                                    data-print_recept_no="{{$receipts->Receipt_Number}}"
                                                                                                                    data-letter_no="2">
                                                                                                                    <i class="fa fa-print" aria-hidden="true"></i>Print Letter</button>
                                                                                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                                                                                                    aria-label="Close">Close</button>
                                                                                                            </div>
                                                                                                    </form>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                @else
                                                                    <td>
                                                                        <a href="" id="show_letter"
                                                                            class="btn btn-sm btn-success bg-success-light text-success me-2"
                                                                            data-bs-toggle="modal" data-bs-target="#letterModel{{$receipts->Receipt_Number}}"
                                                                            data-id="{{$receipts->id}}"
                                                                            data-Customer_NIC="{{$receipts->Customer_NIC}}"
                                                                            data-Customer_Name="{{$receipts->Customer_Name}}"
                                                                            data-Customer_Address="{{$receipts->Customer_Address}}"
                                                                            data-Customer_Phone="{{$receipts->Customer_Phone}}"
                                                                            data-Receipt_Number="{{$receipts->Receipt_Number}}"
                                                                            data-Receipt_Type="{{$receipts->Receipt_Type}}"
                                                                            data-Receipt_Date="{{$receipts->Receipt_Date}}"
                                                                            data-Amount="{{$receipts->Amount}}">
                                                                            <i class="far fa-edit me-1"></i> 1 st Letter
                                                                        </a>
                                                                        {{-- ............Letter 1 model................................. --}}
                                                                        <div class="modal fade" id="letterModel{{$receipts->Receipt_Number}}" tabindex="-1" role="dialog" aria-labelledby="letterModelLabel"
                                                                            aria-hidden="true">
                                                                            <div class="modal-dialog modal-lg">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h4 class="modal-title m-1" id="updateReceiptModelLabel"> Redeem Letter </h4>
                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="col-md-12">
                                                                                            <div class="card">
                                                                                                <div class="card-body">
                                                                                                    <div class="errMsgContainer2"></div>
                                                                                                    <form action="" method="post" id="updateReceipt">
                                                                                                        @csrf
                                                                                                        <h4 class="text-center">1st Reminder Letter</h4>
                                                                                                        <div class="row">
                                                                                                            <div>
                                                                                                                <p>
                                                                                                                    [Your Name] <br>
                                                                                                                    [Your Address] <br>
                                                                                                                    [City, State, Zip Code] <br>
                                                                                                                    [Your Phone Number] <br>
                                                                                                                    [Today's Date] <br>
                                                                                                                    <br>
                                                                                                                    {{$receipts->Customer_Name}}<br>
                                                                                                                    {{$receipts->Customer_Address}} <br>
                                                                                                                    <br>
                                                                                                                    Dear {{$receipts->Customer_Name}}, <br>
                                                                                                                    <br>
                                                                                                                    We hope this letter finds you well. We are writing to remind you of the redemption of your pawn<br>
                                                                                                                    with us, which is now late. As per our records, your pawn, with the following details: <br>
                                                                                                                    <br>
                                                                                                                    Customer ID: {{$receipts->Customer_NIC}} <br>
                                                                                                                    Name: {{$receipts->Customer_Name}} <br>
                                                                                                                    Address: {{$receipts->Customer_Address}} <br>
                                                                                                                    Phone Number: {{$receipts->Customer_Phone}} <br>
                                                                                                                    Receipt Number: {{$receipts->Receipt_Number}}<br>
                                                                                                                    Redemption Date: {{$receipts->Receipt_Date}} <br>
                                                                                                                    Redemption Amount: {{$receipts->Amount}} <br>
                                                                                                                    <br>
                                                                                                                    was due for redemption on {{$receipts->Receipt_Date}}. However, we understand that circumstances <br>
                                                                                                                    may have caused a delay in the redemption process. <br>
                                                                                                                    <br>
                                                                                                                    Please be advised that a late redemption fee may apply as per our terms and conditions. However, <br>
                                                                                                                    we are willing to work with you to resolve this matter promptly.Kindly get in touch with our <br>
                                                                                                                    customer service team at {{$company_number}} to discuss the next steps and to ensure the smooth <br>
                                                                                                                    completion of your pawn redemption.<br>
                                                                                                                    <br>
                                                                                                                    We value your patronage and are committed to providing you with the best possible service.Thank <br>
                                                                                                                    you for your attention to this matter, and we look forward to assisting you in resolving this issue. <br>
                                                                                                                    <br>
                                                                                                                    Sincerely,<br>
                                                                                                                    <br>
                                                                                                                    {{$company_name}}<br>
                                                                                                                    {{$company_address}}<br>
                                                                                                                    {{$company_number}}<br>
                                                                                                                </p>
                                                                                                            </div>

                                                                                                            <div class="text-center mt-4">
                                                                                                                <button type="button"
                                                                                                                    class="btn btn-success print_letter bg-success-light text-success me-2"
                                                                                                                    data-print_recept_no="{{$receipts->Receipt_Number}}"
                                                                                                                    data-letter_no="1">
                                                                                                                    <i class="fa fa-print" aria-hidden="true"></i>Print Letter</button>
                                                                                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                                                                                                    aria-label="Close">Close</button>
                                                                                                            </div>
                                                                                                    </form>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                @endif

                                                            </tr>
                                                            @php
                                                                $sum_total += $receipts->Amount;
                                                            @endphp
                                                            @endforeach
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <td colspan="8" style="text-align: center">Total:</td>
                                                                <td class="text-end">{{number_format($sum_total, 2)}}</td>
                                                                <td></td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                    <div class="m-1">
                                                        {!! $recipts->links() !!}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div class="col-md-1"></div>
                        </div>

                        <div style="display: none">
                            <table class="styled-table text-center" id="LateRedeemtable" >
                                <br>
                                <caption>Late Redeem Reminder Receipt</caption>
                                <br>
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <br>
                                <thead>
                                    <tr>
                                        <th>NIC</th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Phone</th>
                                        <th>Receipt No</th>
                                        <th>Receipt Type</th>
                                        <th>Date</th>
                                        <th>Final Date</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($recipts as $key => $receipts)
                                    <tr>
                                        <td>{{ $receipts->Customer_NIC }}</td>
                                        <td>{{ $receipts->Customer_Name }}</td>
                                        <td>{{ $receipts->Customer_Address }}</td>
                                        <td>{{ $receipts->Customer_Phone }}</td>
                                        <td>{{ $receipts->Receipt_Number }}</td>
                                        <td>{{ $receipts->Receipt_Type }}</td>
                                        <td>{{ $receipts->Receipt_Date }}</td>
                                        <td>{{ $receipts->Final_date }}</td>
                                        <td class="text-end">{{ $receipts->Amount }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {!! Toastr::message() !!}



        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>

        <script>
            $(document).ready(function(){
                //show letter details in letter
                $(document).on('click','#show_letter',function(){
                    let id = $(this).data('id');
                    let c_nic = $(this).data('Customer_NIC');
                    let c_name = $(this).data('Customer_Name');
                    let c_address = $(this).data('Customer_Address');
                    let c_phone = $(this).data('Customer_Phone');
                    let r_number = $(this).data('Receipt_Number');
                    let r_type = $(this).data('Receipt_Type');
                    let r_date = $(this).data('Receipt_Date');
                    let r_amount = $(this).data('Amount');

                    $('#c_nic').val(c_nic);
                    $('#c_name').html(c_name);
                    // $('#c_name').val(c_name);
                    $('#c_address').val(c_address);
                    $('#c_phone').val(c_phone);
                    $('#r_number').val(r_number);
                    $('#r_type').val(r_type);
                    $('#r_date').val(r_date);
                    $('#r_amount').val(r_amount);
                });

                //add new receipt
                $(document).on('click','.add_receipt', function(e){
                    e.preventDefault();
                    let receiptname = $('#receiptname').val();
                    let rate1 = $('#rate1').val();
                    let period1 = $('#period1').val();
                    let rate2 = $('#rate2').val();
                    let period2 = $('#period2').val();
                    let rate3 = $('#rate3').val();
                    let period3 = $('#period3').val();
                    let valid = $('#valid_period').val();
                    let s_char_less = $('#service_charge_less').val();
                    let s_char_grea = $('#service_charge_greater').val();

                    $.ajax({
                        url:"{{ route('add_receipt_ajax') }}",
                        method: 'post',
                        data:{"_token": "{{ csrf_token() }}",
                        receiptname:receiptname,
                        rate1:rate1,
                        period1:period1,
                        rate2:rate2,
                        period2:period2,
                        rate3:rate3,
                        period3:period3,
                        valid:valid,
                        s_char_less:s_char_less,
                        s_char_grea:s_char_grea,
                    },
                        success:function(res){
                            if(res.status=='success'){
                                $('#addReceipt')[0].reset();
                                $('.table').load(location.href+' .table');
                                Command: toastr["success"]("Receipt Added ...!", "Success")
                                    toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": false,
                                    "progressBar": true,
                                    "positionClass": "toast-top-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "300",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                    }
                            }
                        },error:function(err){
                            $('.errMsgContainer1').html('');
                                    let error = err.responseJSON;
                                    $.each(error.errors,function(index, value){
                                        $('.errMsgContainer1').append('<span class="text-danger">'+value+'<span>'+'<br>');

                                    });
                        }
                    })
                })


                //print letter details
                $(document).on('click','.print_letter',function(e){
                            e.preventDefault();
                            let print_recept_no = $(this).data('print_recept_no');
                            let letter_no = $(this).data('letter_no');

                            var confirmPrintSecond = confirm("Do you want to print the letter?");
                            if (confirmPrintSecond) {
                                $.ajax({
                                    url:"{{ route('print_late_redeem_letter_ajax') }}",
                                    method: 'get',
                                    data:{"_token": "{{ csrf_token() }}",
                                    print_recept_no: print_recept_no,
                                    letter_no: letter_no,
                                    },

                                    success:function(res){
                                        if(res.status=='success'){
                                            $("#letterModel"+print_recept_no).modal('hide');
                                            // $('#updateReceipt')[0].reset();
                                            $('.table').load(location.href+' .table');
                                            Command: toastr["success"]("Letter Datails Print Updated...", "Success")
                                                toastr.options = {
                                                "closeButton": true,
                                                "debug": false,
                                                "newestOnTop": false,
                                                "progressBar": true,
                                                "positionClass": "toast-top-right",
                                                "preventDuplicates": false,
                                                "onclick": null,
                                                "showDuration": "300",
                                                "hideDuration": "1000",
                                                "timeOut": "5000",
                                                "extendedTimeOut": "1000",
                                                "showEasing": "swing",
                                                "hideEasing": "linear",
                                                "showMethod": "fadeIn",
                                                "hideMethod": "fadeOut"
                                                }

                                            if(letter_no > 1){
                                                location.reload();
                                            }
                                        }
                                    },error:function(err){
                                        $('.errMsgContainer2').html('');
                                        let error = err.responseJSON;
                                        $.each(error.errors,function(index, value){
                                            $('.errMsgContainer2').append('<span class="text-danger">'+value+'<span>'+'<br>');

                                        });
                                    }
                                })
                            }
                })

                //delete receipt data
                $(document).on('click','.delete_receipt',function(e){
                            e.preventDefault();
                            let receipt_id = $(this).data('id');

                            if(confirm('Are you sure to delete receipt ?')){
                                $.ajax({
                                    url:"{{ route('delete_receipt_ajax') }}",
                                    method: 'post',
                                    data:{"_token": "{{ csrf_token() }}",receipt_id:receipt_id},
                                    success:function(res){
                                        if(res.status=='success'){
                                            $('.table').load(location.href+' .table');
                                            Command: toastr["success"]("Receipt deleted...", "Success")
                                            toastr.options = {
                                            "closeButton": true,
                                            "debug": false,
                                            "newestOnTop": false,
                                            "progressBar": true,
                                            "positionClass": "toast-top-right",
                                            "preventDuplicates": false,
                                            "onclick": null,
                                            "showDuration": "300",
                                            "hideDuration": "1000",
                                            "timeOut": "5000",
                                            "extendedTimeOut": "1000",
                                            "showEasing": "swing",
                                            "hideEasing": "linear",
                                            "showMethod": "fadeIn",
                                            "hideMethod": "fadeOut"
                                            }
                                        }
                                    }
                                });
                            }
                })
            });
        </script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
        <script src="assets/js/jquery-3.6.0.min.js"></script>
        <script src="assets/js/feather.min.js"></script>
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/plugins/datatables/datatables.min.js"></script>
        <script src="assets/js/script.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
        <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
        
        <script>
    var dateObj = new Date();
    document.getElementById('to_date').value = dateObj.toISOString().slice(0, 10);

</script>


<script>
    function printLateRedeemTable() {
      var tableContent = document.getElementById("LateRedeemtable").outerHTML;
      var printWindow = window.open("", "_blank");
  
      printWindow.document.write(`
        <html>
          <head>
            <title>Print Table</title>
            <style>
              table { border-collapse: collapse; width: 100%; }
              table, th, td { border: 1px solid black; padding: 8px; text-align: left; }
            </style>
          </head>
          <body>
            ${tableContent}
            <script>
              window.onload = function() {
                window.print();
                window.onafterprint = function() { window.close(); };
              };
            <\/script>
          </body>
        </html>
      `);
  
      printWindow.document.close();
    }
  </script>

    </body>
@endsection
</html>