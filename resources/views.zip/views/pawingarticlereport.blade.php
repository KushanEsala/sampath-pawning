@if($recipts->count() > 0)
<h2 class="text-center">Pawning Articale Report</h2>

@else
<p class="text-center text-danger">No results found.</p>
@endif

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pawning Articale Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- DataTables & Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <style>
        table.dataTable th, table.dataTable td {
            white-space: nowrap;
        }
    </style>
</head>
<body class="p-3">

    <!-- Date Filter Form -->
    <form action="" method="get" class="mb-4 d-flex gap-3 align-items-end">
        <div>
            <label for="from_date" class="form-label">From Date:</label>
            <input type="date" name="from_date" id="from_date" class="form-control">
        </div>

        <div>
            <label for="to_date" class="form-label">To Date:</label>
            <input type="date" name="to_date" id="to_date" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Search</button>

       <a href="{{ route('home') }}" class="btn btn-secondary">Back</a>
    </form>

    <!-- Receipt Table -->
    <div class="table-responsive">
                 <table class="table table-bordered table-striped display nowrap" id="receiptTable">
                   <thead class="table-dark text-center">
                    <tr>
                        <th>Receipt Number</th>
                        <th>Invoice Number</th>
                        <th>Receipt Type</th>
                        <th>Category</th>
                        <th>Articles</th>
                        <th>Condition</th>
                        <th>Karatage</th>
                        <th>Pawn Weight</th>
                        <th>Total Weight</th>
                        <th>QTY</th>
                        <th>OC</th>
                        <th>BC</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($redeem as $item)
                    <tr>
                        <td>{{ $item->Receipt_Number }}</td>
                        <td>{{ $item->Invoice_Number }}</td>
                        <td>{{ $item->Receipt_Type }}</td>
                        <td>{{ $item->Category }}</td>
                        <td>{{ $item->Articles }}</td>
                        <td>{{ $item->Condition }}</td>
                        <td>{{ $item->Karatage }}</td>
                        <td>{{ $item->Weight }}</td>
                        <td>{{ $item->Total_Weight }}</td>
                        <td>{{ $item->QTY }}</td>
                        <td>{{ $item->OC }}</td>
                        <td>{{ $item->BC }}</td>
                    </tr>
                    @endforeach
                </tbody>
                <tfoot>
                      <tr class="table-secondary text-center">
                        <th colspan="7">Total</th>
                        <th>{{ $pawnWeight }}</th>
                        <th>{{ $totalWeight }}</th>
                        <th>{{ $pawnqty }}</th>
                        <th colspan="2"></th>
                    </tr>
                </tfoot>
            </table>
    </div>

    <!-- Print Button -->
    <div class="mt-3 text-center">
        <button onclick="printTablefun()" class="btn btn-success">Print</button>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables and Export Scripts -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <script>
        $(document).ready(function () {
            $('#receiptTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'pdfHtml5',
                    'print'
                ],
                scrollX: true,
                pageLength: 1000
            });

            // Set today's date to 'to_date' input
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('to_date').value = today;
        });

        function printTablefun() {
            let printContent = document.getElementById("receiptTable").outerHTML;
            let newWin = window.open("");
            newWin.document.write("<html><head><title>Print</title>");
            newWin.document.write("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'>");
            newWin.document.write("</head><body>");
            newWin.document.write(printContent);
            newWin.document.write("</body></html>");
            newWin.print();
            newWin.close();
        }
    </script>
</body>
</html>