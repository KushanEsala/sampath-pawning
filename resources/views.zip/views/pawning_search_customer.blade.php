@foreach ($customer_get as $test)
<div class="row">
    <input class="form-control" type="hidden" name="customer_id" />

    <div class="col">
        <label for="late_redeem"><span class="text-danger">L :</span>
            <input class="form-control form-control-lg text-danger " type="text"
                value= "{{$test['LateRedim']}}"
                placeholder="Customer Address"
                name="late_redeem"
                id="late_redeem" readonly/>
        </label>
    </div>

    <div class="col">
        <label for="pending_redeem"><span class="text-warning">P :</span>
            <input class="form-control form-control-lg text-warning" type="text"
                value= "{{$test['Pending']}}"
                placeholder="Customer Address"
                name="pending_redeem"
                id="pending_redeem" readonly/>
        </label>
    </div>

    <div class="col">
        <label for="redeem_pt"><span class="text-success">R :</span>
            <input class="form-control form-control-lg text-success" type="text"
                value= "{{$test['Redempt']}}"
                placeholder="Customer Address"
                name="redeem_pt"
                id="redeem_pt" readonly/>
        </label>
    </div>
<div class="col-md-3">
<label for="customer_id">Customer Name :
    <input class="form-control form-control-lg" type="text"
        value= "{{$test['First_name']}}"
        id="customer_name"
        placeholder="First Name:"
        name="customer_name"
        readonly/>
</label>
</div>
<div class="col-md-3">
<label for="customer_address">Customer Address :
    <input class="form-control form-control-lg" type="text"
        value= "{{$test['Address_1']}}"
        placeholder="Customer Address"
        name="customer_address"
        id="customer_address" readonly/>
</label>
</div>
<div class="col-md-2">
<label for="customer_contact_1">Phone Number :
    <input class="form-control form-control-lg" type="text"
        value= "{{$test['Contact_1']}}"
        placeholder="Customer Address"
        name="customer_contact_1"
        id="customer_contact_1" readonly/>

        <input type="hidden" value= "{{$test['First_name']}}" name="first_name" id="first_name" readonly/>
        <input type="hidden" value= "{{$test['Middle_name']}}" name="middle_name" id="middle_name" readonly/>
        <input type="hidden" value= "{{$test['Last_name']}}" name="last_name" id="last_name" readonly/>

    </label>
</div>
</div>
@endforeach
