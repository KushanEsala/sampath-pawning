<div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
    <div class="header header-one">
        <div class="header-left header-left-one">
            <a href="index.html" class="logo mt-2">
                <img src="https://i.ibb.co/F4VxjFy/Untitled.jpg" alt="Logo">
            </a>
         </div>
        <a href="javascript:void(0);" id="toggle_btn">
           <i class="fas fa-bars"></i>
        </a>
        <ul class="nav nav-tabs user-menu">
            <li>
               <a href="">Branch : <span>{{ Auth::user()->Branch}}</span></a>
            </li>
            <li class="nav-item dropdown has-arrow main-drop">
                <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">

                <span>{{ Auth::user()->username}}</span>
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href=""><i data-feather="user" class="me-1"></i>
                        Profile</a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                         {{ __('Logout') }}
                     </a>

                     <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                         @csrf
                     </form>
                </div>

            </li>

        </ul>

    </div>
    </div>
