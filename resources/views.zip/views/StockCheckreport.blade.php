
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Receipts</title>

    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid rgb(8, 8, 8);
            padding: 5px;
        }
    </style>

    <!-- Include jQuery and DataTables CSS and JS libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
</head>

<body>
    <form action="" method="get">
        <label for="from_date">From Date:</label>
        <input type="date" name="from_date" id="from_date">

        <label for="to_date">To Date:</label>
        <input type="date" name="to_date" id="to_date">

        <button type="submit">Search</button>
        <button type="button" onclick="printTablefun()">Print</button>
        <button><a href="{{ route('home') }}">Back</a></button>

        <button onclick="printTablefun()">Print</button>

        <button type="button" id="resetCheckboxStock">Reset All Checkbox Stock</button>

    </form>

    <div class="d-flex justify-content-center profile-container">
        <div class="col-md-6 text-center" id="sort-profile">
            <h1 style="text-align:center;"><b>Stock Report</b></h1>
            <hr/>

            <table class="table table-light table-striped table-bordered" id="t_pawn_sums" style="background-color: transparent; border:1px solid rgb(193, 26, 26); margin-top:15px;">
                <thead>
                    <tr>
                        <th>Receipt_Number</th>
                        <th>Check</th>
                        <th>Customer_NIC</th>
                        <th>Customer_Name</th>
                        <th>Customer_Address</th>
                        <th>Customer_Phone</th>
                        <th>Receipt_Type</th>
                        <th>Receipt_Date</th>
                        <th>Amount</th>
                        {{-- <th>Interest</th> --}}
                    </tr>
                </thead>
                <tbody>
                    @foreach ($recipts as $key => $receipt)
                        <tr style="background-color: {{ $receipt->checkbox_stock == 1 ? 'rgb(29, 238, 238)' : '' }};">
                            <td>{{ $receipt->Receipt_Number }}</td>
                            <td>
                                <input 
                                    class="form-check-input save-checkbox" 
                                    type="checkbox" 
                                    data-receipt_number="{{ $receipt->Receipt_Number }}"  
                                    id="flexCheckDefault{{ $receipt->Receipt_Number }}"
                                >
                            </td>                                              
                            <td>{{ $receipt->Customer_NIC }}</td>
                            <td>{{ $receipt->Customer_Name }}</td>
                            <td>{{ $receipt->Customer_Address }}</td>
                            <td>{{ $receipt->Customer_Phone }}</td>
                            <td>{{ $receipt->Receipt_Type }}</td>
                            <td>{{ $receipt->Receipt_Date }}</td>
                            <td>{{ $receipt->Amount }}</td>
                            {{-- <td>{{ $receipt->Interest }}</td> --}}
                        </tr>
                    @endforeach
                </tbody>
                
                <tfoot>
                    <tr>
                        <td colspan="1"><b>Total Pawn Count = {{ $pawnCount }}</b></td>
                        <td colspan="5" style="text-align: center;"><b>Total:</b></td>
                        <td><b>{{ $amount }}</b></td>
                        {{-- <td><b>{{ $Interest }}</b></td> --}}
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>



    <script>
        function printTablefun() {
            var divToPrint = document.getElementById("t_pawn_sums");
            var newWin = window.open("");
            newWin.document.write(divToPrint.outerHTML);
            newWin.print();
            newWin.close();
        }
    
        $(document).ready(function() {
            $('#t_pawn_sums').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'excel', 'csv', 'pdf', 'print'
                ],
                lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],  // Position "All" at the end
                pageLength: -1  // Default to showing all records initially
            });
        });
    </script>
    



<script>
    function printTablefun() {
        var divToPrint = document.getElementById("t_pawn_sums");
        newWin = window.open("");
        newWin.document.write(divToPrint.outerHTML);
        newWin.print();
        newWin.close();
    }

    function printtbodyfun() {
        var divToPrint = document.getElementById("t_pawn_sums");
        newWin = window.open("");
        newWin.document.write(divToPrint.outerHTML);
        newWin.print();
        newWin.close();
    }
</script>


<script>
    $(document).ready(function() {
        $('.save-checkbox').on('change', function() {
            var checkbox = $(this);
            var isChecked = checkbox.is(':checked') ? 1 : 0;  // 1 if checked, 0 if not
            var recordId = checkbox.data('receipt_number');  // Get the record ID

            // Change color of the full row based on checkbox state
            if (isChecked) {
                checkbox.closest('tr').css('background-color', 'rgb(29, 238, 238)');  // Light green for checked
            } else {
                checkbox.closest('tr').css('background-color', '#f8d7da');  // Light red for unchecked
            }

            // Send the data via AJAX
            $.ajax({
                url: '/update-checkbox',  // Replace with your route URL
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',  // CSRF token for Laravel
                    Receipt_Number: recordId,
                    checked: isChecked
                },
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        // Reset all checkbox_stock values to 0
        $('#resetCheckboxStock').on('click', function() {
            // Send the request to reset the checkbox_stock for all records
            $.ajax({
                url: '/reset-checkbox-stock',  // Route to reset the checkbox_stock
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',  // CSRF token for security
                },
                success: function(response) {
                    // Update the table if necessary
                    alert('All checkbox stocks have been reset.');
                    // Optionally, you can reload the page to reflect the changes
                    location.reload();
                },
                error: function(xhr, status, error) {
                    alert('Error resetting checkbox stock.');
                }
            });
        });
    });
</script>


<script>
    var dateObj = new Date();
    document.getElementById('to_date').value = dateObj.toISOString().slice(0, 10);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>

